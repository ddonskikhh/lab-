<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Задания - Таблица умножения, Календарь, Регистрация</title>
    <style>
        /* Стили остаются такими же как в вашем коде */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: #333;
            min-height: 100vh;
            padding: 20px;
        }

        .container {
            max-width: 1400px;
            margin: 0 auto;
            background: white;
            border-radius: 15px;
            padding: 30px;
            box-shadow: 0 15px 35px rgba(0, 0, 0, 0.2);
        }

        header {
            text-align: center;
            margin-bottom: 40px;
        }

        h1 {
            color: #2c3e50;
            margin-bottom: 10px;
            font-size: 2.8rem;
        }

        .subtitle {
            color: #7f8c8d;
            font-size: 1.2rem;
        }

        .tasks-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(450px, 1fr));
            gap: 40px;
            margin-bottom: 40px;
        }

        .task-card {
            background: #f8f9fa;
            border-radius: 15px;
            padding: 30px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }

        .task-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.15);
        }

        .task-card h2 {
            color: #3498db;
            margin-bottom: 25px;
            padding-bottom: 15px;
            border-bottom: 3px solid #3498db;
            font-size: 1.8rem;
        }

        /* Стили для таблицы умножения */
        .multiplication-table-container {
            overflow-x: auto;
            margin-top: 20px;
            padding: 10px;
            border-radius: 10px;
            background: #fff;
            box-shadow: inset 0 0 10px rgba(0,0,0,0.1);
        }

        .multiplication-table {
            display: grid;
            grid-template-columns: repeat(12, 1fr);
            gap: 4px;
            min-width: 900px;
            margin: 0 auto;
        }

        .multiplication-table > div {
            padding: 12px 8px;
            text-align: center;
            border: 1px solid #ddd;
            font-weight: bold;
            border-radius: 5px;
            font-size: 1rem;
            min-height: 50px;
            display: flex;
            align-items: center;
            justify-content: center;
            position: relative;
        }

        /* Угловая ячейка */
        .multiplication-table > div:nth-child(1) {
            background: linear-gradient(135deg, #3498db, #2980b9);
            color: white;
            font-weight: bold;
            font-size: 1.2rem;
            border: 2px solid #2980b9;
        }

        /* Заголовки строк */
        .multiplication-table > div.header-row {
            background: linear-gradient(135deg, #2ecc71, #27ae60);
            color: white;
            font-weight: bold;
            font-size: 1.1rem;
            border: 2px solid #27ae60;
        }

        /* Заголовки столбцов */
        .multiplication-table > div.header-col {
            background: linear-gradient(135deg, #e74c3c, #c0392b);
            color: white;
            font-weight: bold;
            font-size: 1.1rem;
            border: 2px solid #c0392b;
        }

        /* Обычные ячейки */
        .multiplication-table > div.cell {
            background: #ecf0f1;
            transition: all 0.2s ease;
            cursor: pointer;
        }

        .multiplication-table > div.cell:hover {
            background: #d5dbdb;
            transform: scale(1.05);
            box-shadow: 0 3px 8px rgba(0, 0, 0, 0.2);
            z-index: 1;
        }

        .multiplication-table > div.cell:hover::after {
            content: attr(data-tooltip);
            position: absolute;
            bottom: 100%;
            left: 50%;
            transform: translateX(-50%);
            background: rgba(0,0,0,0.8);
            color: white;
            padding: 8px 12px;
            border-radius: 5px;
            font-size: 0.9rem;
            white-space: nowrap;
            z-index: 10;
            margin-bottom: 5px;
        }

        /* Стили для календаря */
        .calendar-controls {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 25px;
            gap: 15px;
            flex-wrap: wrap;
        }

        .calendar-controls input, 
        .calendar-controls select {
            padding: 12px 20px;
            border: 2px solid #ddd;
            border-radius: 8px;
            font-size: 1.1rem;
            flex: 1;
            min-width: 150px;
        }

        .calendar-controls button {
            padding: 12px 25px;
            background: #3498db;
            color: white;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-weight: bold;
            font-size: 1.1rem;
            transition: background 0.3s, transform 0.2s;
        }

        .calendar-controls button:hover {
            background: #2980b9;
            transform: translateY(-2px);
        }

        .calendar-container {
            overflow-x: auto;
        }

        .calendar {
            display: grid;
            grid-template-columns: repeat(7, 1fr);
            gap: 8px;
            min-width: 700px;
        }

        .calendar-day {
            padding: 15px;
            text-align: center;
            border: 2px solid #ddd;
            border-radius: 8px;
            min-height: 80px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            font-size: 1.1rem;
            transition: all 0.2s ease;
        }

        .calendar-day.header {
            background: #3498db;
            color: white;
            font-weight: bold;
            padding: 20px;
            font-size: 1.2rem;
        }

        .calendar-day.weekend {
            background: #ffeaa7;
            color: #d63031;
        }

        .calendar-day.holiday {
            background: linear-gradient(135deg, #fd79a8, #e84393);
            color: white;
            font-weight: bold;
        }

        .calendar-day.other-month {
            background: #f5f5f5;
            color: #bdc3c7;
            opacity: 0.7;
        }

        .calendar-day.today {
            border: 3px solid #3498db;
            background: #d6eaf8;
            box-shadow: 0 0 10px rgba(52, 152, 219, 0.3);
        }

        /* Стили для формы регистрации */
        .registration-form {
            display: flex;
            flex-direction: column;
            gap: 25px;
        }

        .form-group {
            display: flex;
            flex-direction: column;
            gap: 12px;
        }

        .form-group label {
            font-weight: bold;
            color: #2c3e50;
            font-size: 1.1rem;
        }

        .form-group input {
            padding: 15px 20px;
            border: 2px solid #ddd;
            border-radius: 8px;
            font-size: 1.1rem;
            transition: all 0.3s;
        }

        .form-group input:focus {
            outline: none;
            border-color: #3498db;
            box-shadow: 0 0 0 3px rgba(52, 152, 219, 0.2);
        }

        .password-strength {
            height: 8px;
            background: #ddd;
            border-radius: 4px;
            margin-top: 10px;
            overflow: hidden;
        }

        .password-strength-bar {
            height: 100%;
            width: 0%;
            transition: width 0.3s, background 0.3s;
            border-radius: 4px;
        }

        .strength-weak { background: #e74c3c; width: 33%; }
        .strength-medium { background: #f39c12; width: 66%; }
        .strength-strong { background: #2ecc71; width: 100%; }

        .submit-btn {
            padding: 18px;
            background: #2ecc71;
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 1.2rem;
            font-weight: bold;
            cursor: pointer;
            transition: all 0.3s;
        }

        .submit-btn:hover {
            background: #27ae60;
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(39, 174, 96, 0.3);
        }

        .validation-message {
            color: #e74c3c;
            font-size: 1rem;
            margin-top: 8px;
            display: none;
            padding: 8px 12px;
            background: #ffeaea;
            border-radius: 5px;
            border-left: 4px solid #e74c3c;
        }

        .validation-message.show {
            display: block;
        }

        footer {
            text-align: center;
            margin-top: 50px;
            padding-top: 25px;
            border-top: 2px solid #ddd;
            color: #7f8c8d;
            font-size: 1rem;
        }

        @media (max-width: 1024px) {
            .container {
                max-width: 95%;
                padding: 20px;
            }
            
            .tasks-grid {
                grid-template-columns: 1fr;
                gap: 30px;
            }
            
            .multiplication-table {
                min-width: 700px;
                font-size: 0.9rem;
            }
            
            .calendar {
                min-width: 500px;
            }
        }

        @media (max-width: 768px) {
            h1 {
                font-size: 2.2rem;
            }
            
            .subtitle {
                font-size: 1rem;
            }
            
            .task-card {
                padding: 20px;
            }
            
            .task-card h2 {
                font-size: 1.5rem;
            }
            
            .calendar-day {
                min-height: 60px;
                font-size: 1rem;
                padding: 10px;
            }
            
            .calendar-day.header {
                padding: 15px;
                font-size: 1.1rem;
            }
        }

        @media (max-width: 480px) {
            .calendar-controls {
                flex-direction: column;
                align-items: stretch;
            }
            
            .calendar-controls input,
            .calendar-controls select {
                width: 100%;
            }
            
            .multiplication-table > div {
                padding: 8px 5px;
                font-size: 0.9rem;
                min-height: 40px;
            }
        }
        
        .message {
            padding: 15px;
            margin: 10px 0;
            border-radius: 5px;
            font-weight: bold;
        }
        
        .message.success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        
        .message.error {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
    </style>
</head>
<body>
    <div class="container">
        <header>
            <h1>Три задания на PHP/JavaScript</h1>
            <p class="subtitle">Таблица умножения • Календарь • Форма регистрации</p>
        </header>

        <div class="tasks-grid">
            <!-- Задание 1: Таблица умножения (генерируется PHP) -->
            <div class="task-card">
                <h2>Задание 1: Таблица умножения (0-10)</h2>
                <p>Таблица умножения чисел от 0 до 10:</p>
                <div class="multiplication-table-container">
                    <div class="multiplication-table" id="multiplicationTable">
                        <?php
                        // Генерация таблицы умножения на PHP
                        echo '<div>×</div>'; // Угловая ячейка
                        
                        // Заголовки столбцов
                        for ($i = 0; $i <= 10; $i++) {
                            echo '<div class="header-col">' . $i . '</div>';
                        }
                        
                        // Основная часть таблицы
                        for ($i = 0; $i <= 10; $i++) {
                            // Заголовок строки
                            echo '<div class="header-row">' . $i . '</div>';
                            
                            // Ячейки с результатами
                            for ($j = 0; $j <= 10; $j++) {
                                $result = $i * $j;
                                echo '<div class="cell" data-tooltip="' . $i . ' × ' . $j . ' = ' . $result . '">' . $result . '</div>';
                            }
                        }
                        ?>
                    </div>
                </div>
            </div>

            <!-- Задание 2: Календарь -->
            <div class="task-card">
                <h2>Задание 2: Календарь на месяц</h2>
                <div class="calendar-controls">
                    <form method="GET" action="" id="calendarForm">
                        <input type="number" name="year" id="year" min="1900" max="2100" 
                               placeholder="Год" value="<?php echo isset($_GET['year']) ? htmlspecialchars($_GET['year']) : date('Y'); ?>">
                        <select name="month" id="month">
                            <?php
                            $months = [
                                1 => 'Январь', 2 => 'Февраль', 3 => 'Март', 
                                4 => 'Апрель', 5 => 'Май', 6 => 'Июнь',
                                7 => 'Июль', 8 => 'Август', 9 => 'Сентябрь',
                                10 => 'Октябрь', 11 => 'Ноябрь', 12 => 'Декабрь'
                            ];
                            $currentMonth = isset($_GET['month']) ? (int)$_GET['month'] : date('n');
                            foreach ($months as $num => $name) {
                                $selected = ($num == $currentMonth) ? 'selected' : '';
                                echo "<option value=\"$num\" $selected>$name</option>";
                            }
                            ?>
                        </select>
                        <button type="submit">Показать календарь</button>
                    </form>
                </div>
                <div class="calendar-container">
                    <div class="calendar" id="calendar">
                        <?php
                        // Функция для генерации календаря на PHP
                        function generateCalendarPHP($year = null, $month = null) {
                            global $months; // Используем глобальную переменную
                            
                            $year = $year ?? date('Y');
                            $month = $month ?? date('n');
                            
                            // Дни недели
                            $daysOfWeek = ['Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб', 'Вс'];
                            
                            // Выводим заголовки дней
                            foreach ($daysOfWeek as $day) {
                                echo '<div class="calendar-day header" title="' . $day . '">' . $day . '</div>';
                            }
                            
                            // Первый день месяца
                            $firstDay = mktime(0, 0, 0, $month, 1, $year);
                            $daysInMonth = date('t', $firstDay);
                            $startDay = date('N', $firstDay) - 1; // Пн=0, Вт=1, ..., Вс=6
                            
                            // Пустые ячейки перед первым днем
                            $prevMonthDays = date('t', mktime(0, 0, 0, $month - 1, 1, $year));
                            for ($i = 0; $i < $startDay; $i++) {
                                $day = $prevMonthDays - $startDay + $i + 1;
                                echo '<div class="calendar-day other-month">' . $day . '</div>';
                            }
                            
                            // Дни месяца
                            $today = date('j');
                            $currentMonthNum = date('n');
                            $currentYear = date('Y');
                            
                            // Праздничные дни
                            $holidays = [
                                '01-01', '01-02', '01-03', '01-04', '01-05', '01-06', '01-07',
                                '02-23', '03-08', '05-01', '05-09', '06-12', '11-04', '12-31'
                            ];
                            
                            for ($day = 1; $day <= $daysInMonth; $day++) {
                                $date = sprintf('%02d-%02d', $month, $day);
                                $isToday = ($day == $today && $month == $currentMonthNum && $year == $currentYear);
                                $dayOfWeek = date('N', mktime(0, 0, 0, $month, $day, $year));
                                $isWeekend = ($dayOfWeek >= 6);
                                $isHoliday = in_array($date, $holidays);
                                
                                $classes = 'calendar-day';
                                if ($isToday) $classes .= ' today';
                                if ($isWeekend) $classes .= ' weekend';
                                if ($isHoliday) $classes .= ' holiday';
                                
                                $monthName = $months[$month] ?? 'Неизвестный месяц';
                                echo '<div class="' . $classes . '" title="' . $day . ' ' . 
                                     $monthName . ' ' . $year . '">' . $day . '</div>';
                            }
                            
                            // Завершаем сетку следующими днями
                            $totalCells = 42; // 6 строк по 7 дней
                            $currentCells = $startDay + $daysInMonth;
                            if ($currentCells < $totalCells) {
                                for ($i = 1; $i <= ($totalCells - $currentCells); $i++) {
                                    echo '<div class="calendar-day other-month">' . $i . '</div>';
                                }
                            }
                        }
                        
                        // Генерируем календарь
                        $year = isset($_GET['year']) ? (int)$_GET['year'] : date('Y');
                        $month = isset($_GET['month']) ? (int)$_GET['month'] : date('n');
                        generateCalendarPHP($year, $month);
                        ?>
                    </div>
                </div>
            </div>

            <!-- Задание 3: Форма регистрации -->
            <div class="task-card">
                <h2>Задание 3: Регистрация пользователя</h2>
                
                <?php
                // Обработка формы регистрации
                if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['register'])) {
                    $errors = [];
                    $success = false;
                    
                    // Валидация данных
                    $fullName = trim($_POST['fullName'] ?? '');
                    $login = trim($_POST['login'] ?? '');
                    $password = $_POST['password'] ?? '';
                    $birthDate = $_POST['birthDate'] ?? '';
                    
                    // Проверка ФИО
                    if (empty($fullName)) {
                        $errors['fullName'] = 'ФИО обязательно для заполнения';
                    } elseif (strlen($fullName) < 5 || substr_count($fullName, ' ') < 1) {
                        $errors['fullName'] = 'Введите полное ФИО (минимум 2 слова)';
                    }
                    
                    // Проверка логина
                    if (empty($login)) {
                        $errors['login'] = 'Логин обязателен для заполнения';
                    } elseif (strlen($login) < 3) {
                        $errors['login'] = 'Логин должен содержать не менее 3 символов';
                    } elseif (!preg_match('/^[a-zA-Z0-9_]+$/', $login)) {
                        $errors['login'] = 'Логин может содержать только буквы, цифры и подчеркивания';
                    }
                    
                    // Проверка пароля
                    if (empty($password)) {
                        $errors['password'] = 'Пароль обязателен для заполнения';
                    } elseif (strlen($password) < 6) {
                        $errors['password'] = 'Пароль должен содержать не менее 6 символов';
                    } elseif (!preg_match('/[A-Z]/', $password) || 
                              !preg_match('/[a-z]/', $password) || 
                              !preg_match('/[0-9]/', $password)) {
                        $errors['password'] = 'Пароль должен содержать заглавные, строчные буквы и цифры';
                    }
                    
                    // Проверка даты рождения
                    if (empty($birthDate)) {
                        $errors['birthDate'] = 'Дата рождения обязательна для заполнения';
                    } else {
                        $birthDateObj = DateTime::createFromFormat('Y-m-d', $birthDate);
                        $today = new DateTime();
                        $minDate = clone $today;
                        $minDate->modify('-100 years');
                        $maxDate = clone $today;
                        $maxDate->modify('-14 years');
                        
                        if ($birthDateObj > $maxDate) {
                            $errors['birthDate'] = 'Вам должно быть не менее 14 лет';
                        } elseif ($birthDateObj < $minDate) {
                            $errors['birthDate'] = 'Введите корректную дату рождения';
                        }
                    }
                    
                    // Если ошибок нет, сохраняем данные в users.txt
                    if (empty($errors)) {
                        $success = true;
                        
                        // Сохраняем данные в текстовый файл
                        $dataLine = date('Y-m-d H:i:s') . ' | ' . 
                                   $login . ' | ' . 
                                   $fullName . ' | ' . 
                                   $birthDate;
                        
                        file_put_contents('users.txt', $dataLine . PHP_EOL, FILE_APPEND);
                        
                        // Выводим сообщение об успехе
                        echo '<div class="message success">✅ Регистрация успешно завершена! Данные сохранены.</div>';
                    }
                }
                ?>
                
                <form id="registrationForm" class="registration-form" method="POST" action="">
                    <div class="form-group">
                        <label for="fullName">ФИО:</label>
                        <input type="text" id="fullName" name="fullName" 
                               placeholder="Иванов Иван Иванович" 
                               value="<?php echo htmlspecialchars($_POST['fullName'] ?? ''); ?>" 
                               required>
                        <?php if (isset($errors['fullName'])): ?>
                            <div class="validation-message show"><?php echo $errors['fullName']; ?></div>
                        <?php else: ?>
                            <div class="validation-message" id="fullNameError"></div>
                        <?php endif; ?>
                    </div>

                    <div class="form-group">
                        <label for="login">Логин:</label>
                        <input type="text" id="login" name="login" 
                               placeholder="Придумайте логин" 
                               value="<?php echo htmlspecialchars($_POST['login'] ?? ''); ?>" 
                               required>
                        <?php if (isset($errors['login'])): ?>
                            <div class="validation-message show"><?php echo $errors['login']; ?></div>
                        <?php else: ?>
                            <div class="validation-message" id="loginError"></div>
                        <?php endif; ?>
                    </div>

                    <div class="form-group">
                        <label for="password">Пароль:</label>
                        <input type="password" id="password" name="password" 
                               placeholder="Не менее 6 символов" required>
                        <div class="password-strength">
                            <div class="password-strength-bar" id="passwordStrength"></div>
                        </div>
                        <?php if (isset($errors['password'])): ?>
                            <div class="validation-message show"><?php echo $errors['password']; ?></div>
                        <?php else: ?>
                            <div class="validation-message" id="passwordError"></div>
                        <?php endif; ?>
                    </div>

                    <div class="form-group">
                        <label for="birthDate">Дата рождения:</label>
                        <input type="date" id="birthDate" name="birthDate" 
                               value="<?php echo htmlspecialchars($_POST['birthDate'] ?? ''); ?>" 
                               required>
                        <?php if (isset($errors['birthDate'])): ?>
                            <div class="validation-message show"><?php echo $errors['birthDate']; ?></div>
                        <?php else: ?>
                            <div class="validation-message" id="birthDateError"></div>
                        <?php endif; ?>
                    </div>

                    <button type="submit" name="register" class="submit-btn">Зарегистрироваться</button>
                </form>
            </div>
        </div>

        <footer>
            <p>Все задания выполнены с использованием HTML, CSS, PHP и JavaScript</p>
            <p>Текущая дата на сервере: <?php echo date('d.m.Y H:i:s'); ?></p>
        </footer>
    </div>

    <script>
        // JavaScript для клиентской валидации и интерактивности
        document.addEventListener('DOMContentLoaded', function() {
            // Интерактивность таблицы умножения
            const cells = document.querySelectorAll('.multiplication-table .cell');
            cells.forEach(cell => {
                cell.addEventListener('mouseenter', function() {
                    this.style.zIndex = '10';
                });
                cell.addEventListener('mouseleave', function() {
                    this.style.zIndex = '1';
                });
            });

            // Валидация пароля в реальном времени
            const passwordInput = document.getElementById('password');
            const passwordStrength = document.getElementById('passwordStrength');
            
            if (passwordInput) {
                passwordInput.addEventListener('input', function() {
                    const password = this.value;
                    let strength = 0;
                    
                    if (password.length >= 6) strength++;
                    if (/[A-Z]/.test(password)) strength++;
                    if (/[a-z]/.test(password)) strength++;
                    if (/[0-9]/.test(password)) strength++;
                    if (/[^A-Za-z0-9]/.test(password)) strength++;
                    
                    passwordStrength.className = 'password-strength-bar';
                    if (password.length === 0) {
                        // Сбрасываем если поле пустое
                    } else if (strength <= 2) {
                        passwordStrength.classList.add('strength-weak');
                    } else if (strength <= 4) {
                        passwordStrength.classList.add('strength-medium');
                    } else {
                        passwordStrength.classList.add('strength-strong');
                    }
                });
            }

            // AJAX для календаря
            const calendarForm = document.getElementById('calendarForm');
            if (calendarForm) {
                calendarForm.addEventListener('submit', function(e) {
                    // Можно добавить AJAX загрузку календаря без перезагрузки страницы
                    // Для простоты оставляем стандартную отправку формы
                });
            }

            // Установка ограничений для даты рождения
            const birthDateInput = document.getElementById('birthDate');
            if (birthDateInput) {
                const today = new Date();
                const maxDate = new Date();
                maxDate.setFullYear(today.getFullYear() - 14);
                const minDate = new Date();
                minDate.setFullYear(today.getFullYear() - 100);
                
                if (!birthDateInput.value) {
                    birthDateInput.max = maxDate.toISOString().split('T')[0];
                    birthDateInput.min = minDate.toISOString().split('T')[0];
                }
            }

            // Клиентская валидация формы
            const registrationForm = document.getElementById('registrationForm');
            if (registrationForm) {
                registrationForm.addEventListener('submit', function(event) {
                    let isValid = true;
                    
                    // Валидация ФИО
                    const fullName = document.getElementById('fullName').value.trim();
                    const fullNameError = document.getElementById('fullNameError');
                    if (fullName.split(' ').length < 2 || fullName.length < 5) {
                        fullNameError.textContent = 'Введите полное ФИО (минимум 2 слова)';
                        fullNameError.classList.add('show');
                        isValid = false;
                    } else {
                        fullNameError.classList.remove('show');
                    }
                    
                    // Валидация логина
                    const login = document.getElementById('login').value.trim();
                    const loginError = document.getElementById('loginError');
                    if (login.length < 3) {
                        loginError.textContent = 'Логин должен содержать не менее 3 символов';
                        loginError.classList.add('show');
                        isValid = false;
                    } else if (!/^[a-zA-Z0-9_]+$/.test(login)) {
                        loginError.textContent = 'Логин может содержать только буквы, цифры и подчеркивания';
                        loginError.classList.add('show');
                        isValid = false;
                    } else {
                        loginError.classList.remove('show');
                    }
                    
                    // Валидация пароля
                    const password = document.getElementById('password').value;
                    const passwordError = document.getElementById('passwordError');
                    if (password.length < 6) {
                        passwordError.textContent = 'Пароль должен содержать не менее 6 символов';
                        passwordError.classList.add('show');
                        isValid = false;
                    } else if (!/(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/.test(password)) {
                        passwordError.textContent = 'Пароль должен содержать заглавные, строчные буквы и цифры';
                        passwordError.classList.add('show');
                        isValid = false;
                    } else {
                        passwordError.classList.remove('show');
                    }
                    
                    // Валидация даты рождения
                    const birthDate = document.getElementById('birthDate').value;
                    const birthDateError = document.getElementById('birthDateError');
                    if (!birthDate) {
                        birthDateError.textContent = 'Пожалуйста, введите дату рождения';
                        birthDateError.classList.add('show');
                        isValid = false;
                    } else {
                        const birthDateObj = new Date(birthDate);
                        const today = new Date();
                        const minDate = new Date();
                        minDate.setFullYear(today.getFullYear() - 100);
                        const maxDate = new Date();
                        maxDate.setFullYear(today.getFullYear() - 14);
                        
                        if (birthDateObj > maxDate) {
                            birthDateError.textContent = 'Вам должно быть не менее 14 лет';
                            birthDateError.classList.add('show');
                            isValid = false;
                        } else if (birthDateObj < minDate) {
                            birthDateError.textContent = 'Введите корректную дату рождения';
                            birthDateError.classList.add('show');
                            isValid = false;
                        } else {
                            birthDateError.classList.remove('show');
                        }
                    }
                    
                    if (!isValid) {
                        event.preventDefault();
                    }
                });
            }
        });
    </script>
</body>
</html>