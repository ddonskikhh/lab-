// Управление анимацией песочных часов

document.addEventListener('DOMContentLoaded', function() {
    // Элементы для управления
    const startBtn = document.getElementById('start-btn');
    const pauseBtn = document.getElementById('pause-btn');
    const reverseBtn = document.getElementById('reverse-btn');
    const resetBtn = document.getElementById('reset-btn');
    const timeValue = document.getElementById('time-value');
    
    // Элементы с анимациями
    const sandTop = document.querySelector('.sand-top');
    const sandBottom = document.querySelector('.sand-bottom');
    const fallingSand = document.querySelector('.falling-sand');
    const timeProgress = document.querySelector('.time-progress');
    const hourglass = document.querySelector('.hourglass');
    const hourglassScene = document.querySelector('.hourglass-scene');
    
    // Переменные состояния
    let isPaused = false;
    let isReversed = false;
    let timeLeft = 30; // Изменено с 60 до 30 секунд
    let timerInterval;
    
    // Инициализация анимаций
    function initAnimations() {
        // Устанавливаем анимации в начальное состояние
        sandTop.style.animationPlayState = 'running';
        sandBottom.style.animationPlayState = 'running';
        fallingSand.style.animationPlayState = 'running';
        timeProgress.style.animationPlayState = 'running';
        
        // Сбрасываем переворот
        hourglassScene.classList.remove('flipped');
        
        // Сбрасываем направление
        sandTop.style.animationDirection = 'normal';
        sandBottom.style.animationDirection = 'normal';
        fallingSand.style.animationDirection = 'normal';
        timeProgress.style.animationDirection = 'normal';
        hourglassScene.classList.remove('reversed');
        isReversed = false;
        reverseBtn.textContent = 'Обратное движение';
        
        // Убираем паузу
        hourglassScene.classList.remove('paused');
        isPaused = false;
        pauseBtn.textContent = 'Приостановить';
        
        // Запускаем таймер
        startTimer();
    }
    
    // Запуск таймера
    function startTimer() {
        clearInterval(timerInterval);
        timeLeft = 30; // Изменено с 60 до 30 секунд
        timeValue.textContent = timeLeft;
        
        timerInterval = setInterval(() => {
            if (!isPaused) {
                if (isReversed) {
                    timeLeft++;
                    if (timeLeft > 30) timeLeft = 30; // Изменено с 60 до 30
                } else {
                    timeLeft--;
                    if (timeLeft < 0) timeLeft = 0;
                }
                timeValue.textContent = timeLeft;
                
                // Если время истекло, перезапускаем
                if (timeLeft === 0 && !isReversed) {
                    resetAnimations();
                }
            }
        }, 1000);
    }
    
    // Запуск анимации
    startBtn.addEventListener('click', function() {
        if (isPaused) {
            // Возобновляем анимацию
            sandTop.style.animationPlayState = 'running';
            sandBottom.style.animationPlayState = 'running';
            fallingSand.style.animationPlayState = 'running';
            timeProgress.style.animationPlayState = 'running';
            hourglassScene.classList.remove('paused');
            isPaused = false;
            pauseBtn.textContent = 'Приостановить';
        } else {
            // Перезапускаем анимацию
            resetAnimations();
        }
    });
    
    // Пауза/возобновление анимации
    pauseBtn.addEventListener('click', function() {
        if (isPaused) {
            // Возобновляем анимацию
            sandTop.style.animationPlayState = 'running';
            sandBottom.style.animationPlayState = 'running';
            fallingSand.style.animationPlayState = 'running';
            timeProgress.style.animationPlayState = 'running';
            hourglassScene.classList.remove('paused');
            isPaused = false;
            pauseBtn.textContent = 'Приостановить';
        } else {
            // Приостанавливаем анимацию
            sandTop.style.animationPlayState = 'paused';
            sandBottom.style.animationPlayState = 'paused';
            fallingSand.style.animationPlayState = 'paused';
            timeProgress.style.animationPlayState = 'paused';
            hourglassScene.classList.add('paused');
            isPaused = true;
            pauseBtn.textContent = 'Возобновить';
        }
    });
    
    // Обратное движение
    reverseBtn.addEventListener('click', function() {
        isReversed = !isReversed;
        
        if (isReversed) {
            // Устанавливаем обратное направление
            sandTop.style.animationDirection = 'reverse';
            sandBottom.style.animationDirection = 'reverse';
            fallingSand.style.animationDirection = 'reverse';
            timeProgress.style.animationDirection = 'reverse';
            hourglassScene.classList.add('reversed');
            reverseBtn.textContent = 'Обычное движение';
        } else {
            // Возвращаем обычное направление
            sandTop.style.animationDirection = 'normal';
            sandBottom.style.animationDirection = 'normal';
            fallingSand.style.animationDirection = 'normal';
            timeProgress.style.animationDirection = 'normal';
            hourglassScene.classList.remove('reversed');
            reverseBtn.textContent = 'Обратное движение';
        }
        
        // Если анимация на паузе, возобновляем
        if (isPaused) {
            isPaused = false;
            pauseBtn.textContent = 'Приостановить';
            sandTop.style.animationPlayState = 'running';
            sandBottom.style.animationPlayState = 'running';
            fallingSand.style.animationPlayState = 'running';
            timeProgress.style.animationPlayState = 'running';
            hourglassScene.classList.remove('paused');
        }
    });
    
    // Сброс анимации
    resetBtn.addEventListener('click', function() {
        resetAnimations();
    });
    
    // Функция сброса анимаций
    function resetAnimations() {
        // Останавливаем текущие анимации
        sandTop.style.animation = 'none';
        sandBottom.style.animation = 'none';
        fallingSand.style.animation = 'none';
        timeProgress.style.animation = 'none';
        
        // Сбрасываем переворот
        hourglassScene.classList.remove('flipped');
        
        // Сбрасываем состояние
        isPaused = false;
        isReversed = false;
        pauseBtn.textContent = 'Приостановить';
        reverseBtn.textContent = 'Обратное движение';
        hourglassScene.classList.remove('paused');
        hourglassScene.classList.remove('reversed');
        
        // Принудительный reflow для перезапуска анимаций
        void sandTop.offsetWidth;
        void sandBottom.offsetWidth;
        void fallingSand.offsetWidth;
        void timeProgress.offsetWidth;
        
        // Перезапускаем анимации с новым временем (30 секунд)
        sandTop.style.animation = 'sand-top-flow 30s linear infinite';
        sandBottom.style.animation = 'sand-bottom-fill 30s linear infinite';
        fallingSand.style.animation = 'sand-fall 2s linear infinite';
        timeProgress.style.animation = 'time-progress 30s linear infinite';
        
        // Запускаем анимации
        sandTop.style.animationPlayState = 'running';
        sandBottom.style.animationPlayState = 'running';
        fallingSand.style.animationPlayState = 'running';
        timeProgress.style.animationPlayState = 'running';
        
        // Сбрасываем направление
        sandTop.style.animationDirection = 'normal';
        sandBottom.style.animationDirection = 'normal';
        fallingSand.style.animationDirection = 'normal';
        timeProgress.style.animationDirection = 'normal';
        
        // Запускаем таймер
        startTimer();
    }
    
    // Автоматический запуск анимации при загрузке страницы
    resetAnimations();
    
    // Добавляем анимации для елки
    addTreeAnimations();
    
    // Функция для добавления анимаций к елке
    function addTreeAnimations() {
        // Анимация мигания звезды уже есть в CSS
        
        // Анимация украшений уже есть в CSS
        
        // Анимация гирлянды уже есть в CSS
        
        // Анимация подарков при наведении
        const gifts = document.querySelectorAll('.gift');
        gifts.forEach(gift => {
            gift.style.transition = 'transform 0.3s';
            gift.addEventListener('mouseenter', function() {
                this.style.transform = 'translateY(-5px)';
            });
            gift.addEventListener('mouseleave', function() {
                this.style.transform = 'translateY(0)';
            });
        });
    }
});