<?php
// config.php
session_start();

// Настройки БД
define('DB_HOST', '127.0.0.1');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'users');

// Подключение к БД
function getDB() {
    try {
        $pdo = new PDO(
            "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
            DB_USER,
            DB_PASS,
            [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
            ]
        );
        return $pdo;
    } catch(PDOException $e) {
        die("Ошибка подключения: " . $e->getMessage());
    }
}

// Функции для работы с ролями
function hashPassword($password) {
    return password_hash($password, PASSWORD_BCRYPT);
}

// Проверка авторизации
function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

// Проверка роли администратора
function isAdmin() {
    // Если в сессии есть роль и она 'admin'
    if (isset($_SESSION['role']) && $_SESSION['role'] === 'admin') {
        return true;
    }
    
    // Дополнительная проверка из БД (на всякий случай)
    if (isLoggedIn()) {
        try {
            $db = getDB();
            $stmt = $db->prepare("SELECT role FROM users WHERE id = ?");
            $stmt->execute([$_SESSION['user_id']]);
            $user = $stmt->fetch();
            
            if ($user && $user['role'] === 'admin') {
                $_SESSION['role'] = 'admin'; // Обновляем сессию
                return true;
            }
        } catch(Exception $e) {
            // В случае ошибки считаем, что не админ
            return false;
        }
    }
    
    return false;
}

// Проверка роли пользователя
function isUser() {
    return isLoggedIn() && !isAdmin();
}

// Получение текущего пользователя
function getCurrentUser() {
    if (isLoggedIn()) {
        return [
            'id' => $_SESSION['user_id'],
            'login' => $_SESSION['login'] ?? '',
            'email' => $_SESSION['email'] ?? '',
            'role' => $_SESSION['role'] ?? 'user'
        ];
    }
    return null;
}

// Редирект если не авторизован
function requireLogin() {
    if (!isLoggedIn()) {
        header('Location: login.php');
        exit();
    }
}

// Редирект если не администратор
function requireAdmin() {
    requireLogin();
    if (!isAdmin()) {
        // Можно показать сообщение об ошибке
        $_SESSION['error'] = 'Доступ запрещен. Требуются права администратора.';
        header('Location: index.php');
        exit();
    }
}

// Редирект если не обычный пользователь
function requireUser() {
    requireLogin();
    if (isAdmin()) {
        // Админы не могут попасть на страницы только для пользователей
        header('Location: admin.php');
        exit();
    }
}

// Получение списка всех ролей
function getRoles() {
    return [
        'user' => 'Обычный пользователь',
        'admin' => 'Администратор'
    ];
}

// Проверка доступа к определенному действию
function can($action) {
    $permissions = [
        'view_users' => ['admin'],
        'edit_users' => ['admin'],
        'delete_users' => ['admin'],
        'add_users' => ['admin'],
        'edit_profile' => ['user', 'admin'],
        'view_profile' => ['user', 'admin']
    ];
    
    if (!isset($permissions[$action])) {
        return false;
    }
    
    $userRole = $_SESSION['role'] ?? 'user';
    return in_array($userRole, $permissions[$action]);
}
?>