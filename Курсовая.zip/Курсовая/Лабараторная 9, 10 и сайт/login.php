<?php
// login.php
require_once 'config.php';

if (isLoggedIn()) {
    header('Location: index.php');
    exit();
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $login = trim($_POST['login']);
    $password = $_POST['password'];
    
    try {
        $db = getDB();
        $stmt = $db->prepare("SELECT * FROM users WHERE login = ? OR email = ?");
        $stmt->execute([$login, $login]);
        $user = $stmt->fetch();
        
        if ($user && password_verify($password, $user['password'])) {
            // Установка сессии с ролью
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['login'] = $user['login'];
            $_SESSION['email'] = $user['email'];
            $_SESSION['role'] = $user['role'] ?? 'user';
            
            // Редирект в зависимости от роли
            if ($_SESSION['role'] === 'admin') {
                header('Location: admin.php');
            } else {
                header('Location: profile.php');
            }
            exit();
        } else {
            $error = 'Неверный логин/email или пароль';
        }
    } catch(PDOException $e) {
        $error = 'Ошибка при входе: ' . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CINEMAX - Вход в систему</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Arial', sans-serif;
        }
        
        body {
            background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
            color: #fff;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
            position: relative;
            overflow-x: hidden;
        }
        
        body::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: url('https://images.unsplash.com/photo-1489599809516-9827b6d1cf13?auto=format&fit=crop&w=1200&q=80') center/cover;
            opacity: 0.1;
            z-index: -1;
        }
        
        .container {
            width: 100%;
            max-width: 450px;
            position: relative;
            z-index: 1;
        }
        
        .logo {
            text-align: center;
            margin-bottom: 30px;
        }
        
        .logo-text {
            font-size: 48px;
            font-weight: bold;
            color: #ffd700;
            text-transform: uppercase;
            letter-spacing: 3px;
            text-shadow: 0 0 20px rgba(255, 215, 0, 0.5);
            margin-bottom: 5px;
        }
        
        .logo-subtitle {
            color: #aaa;
            font-size: 14px;
            letter-spacing: 2px;
        }
        
        .login-card {
            background: rgba(255, 255, 255, 0.05);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 215, 0, 0.2);
            border-radius: 20px;
            padding: 40px;
            box-shadow: 0 20px 50px rgba(0, 0, 0, 0.3);
            transition: transform 0.3s, box-shadow 0.3s;
        }
        
        .login-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 25px 60px rgba(255, 215, 0, 0.1);
            border-color: rgba(255, 215, 0, 0.4);
        }
        
        .card-header {
            text-align: center;
            margin-bottom: 30px;
        }
        
        .card-icon {
            width: 80px;
            height: 80px;
            background: linear-gradient(135deg, #ffd700 0%, #ffed4e 100%);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 20px;
            font-size: 32px;
            color: #000;
            box-shadow: 0 10px 20px rgba(255, 215, 0, 0.3);
        }
        
        .card-title {
            font-size: 28px;
            color: #fff;
            margin-bottom: 10px;
        }
        
        .card-subtitle {
            color: #aaa;
            font-size: 14px;
        }
        
        /* Форма */
        .form-group {
            margin-bottom: 25px;
            position: relative;
        }
        
        .form-label {
            display: block;
            margin-bottom: 8px;
            color: #ccc;
            font-size: 14px;
            font-weight: 500;
            text-transform: uppercase;
            letter-spacing: 1px;
        }
        
        .input-wrapper {
            position: relative;
        }
        
        .form-input {
            width: 100%;
            padding: 15px 20px 15px 50px;
            background: rgba(255, 255, 255, 0.08);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 10px;
            color: #fff;
            font-size: 16px;
            transition: all 0.3s;
        }
        
        .form-input:focus {
            outline: none;
            border-color: #ffd700;
            background: rgba(255, 255, 255, 0.12);
            box-shadow: 0 0 0 3px rgba(255, 215, 0, 0.1);
        }
        
        .form-input::placeholder {
            color: #777;
        }
        
        .input-icon {
            position: absolute;
            left: 20px;
            top: 50%;
            transform: translateY(-50%);
            color: #ffd700;
            font-size: 18px;
        }
        
        /* Кнопка */
        .submit-btn {
            width: 100%;
            padding: 16px;
            background: linear-gradient(135deg, #ffd700 0%, #ffed4e 100%);
            border: none;
            border-radius: 10px;
            color: #000;
            font-size: 16px;
            font-weight: bold;
            cursor: pointer;
            transition: all 0.3s;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            margin-top: 10px;
        }
        
        .submit-btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 10px 25px rgba(255, 215, 0, 0.4);
        }
        
        .submit-btn:active {
            transform: translateY(-1px);
        }
        
        /* Ошибки */
        .error-message {
            background: rgba(220, 53, 69, 0.1);
            border: 1px solid rgba(220, 53, 69, 0.3);
            border-radius: 10px;
            padding: 15px;
            margin-bottom: 25px;
            color: #ff6b6b;
            font-size: 14px;
            display: flex;
            align-items: center;
            gap: 10px;
            animation: shake 0.5s ease-in-out;
        }
        
        @keyframes shake {
            0%, 100% { transform: translateX(0); }
            25% { transform: translateX(-10px); }
            75% { transform: translateX(10px); }
        }
        
        .error-icon {
            font-size: 18px;
        }
        
        /* Ссылки */
        .links-section {
            text-align: center;
            margin-top: 30px;
            padding-top: 25px;
            border-top: 1px solid rgba(255, 255, 255, 0.1);
        }
        
        .link-text {
            color: #aaa;
            margin-bottom: 15px;
            font-size: 14px;
        }
        
        .action-link {
            display: inline-block;
            padding: 12px 30px;
            background: transparent;
            border: 2px solid rgba(255, 215, 0, 0.3);
            border-radius: 50px;
            color: #ffd700;
            text-decoration: none;
            font-weight: bold;
            transition: all 0.3s;
        }
        
        .action-link:hover {
            background: rgba(255, 215, 0, 0.1);
            border-color: #ffd700;
            transform: translateY(-3px);
        }
        
        .home-link {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            margin-top: 20px;
            color: #777;
            text-decoration: none;
            font-size: 14px;
            transition: color 0.3s;
        }
        
        .home-link:hover {
            color: #ffd700;
        }
        
        /* Дополнительные опции */
        .form-options {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-top: 15px;
            font-size: 14px;
        }
        
        .remember-me {
            display: flex;
            align-items: center;
            gap: 8px;
            color: #aaa;
            cursor: pointer;
        }
        
        .remember-checkbox {
            width: 18px;
            height: 18px;
            accent-color: #ffd700;
        }
        
        .forgot-password {
            color: #ffd700;
            text-decoration: none;
            transition: color 0.3s;
        }
        
        .forgot-password:hover {
            color: #ffed4e;
            text-decoration: underline;
        }
        
        /* Анимация появления */
        .login-card {
            opacity: 0;
            transform: translateY(30px);
            animation: fadeInUp 0.8s ease forwards;
        }
        
        @keyframes fadeInUp {
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        /* Эффект частиц */
        .particles {
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            z-index: -1;
            pointer-events: none;
        }
        
        .particle {
            position: absolute;
            background: rgba(255, 215, 0, 0.3);
            border-radius: 50%;
            animation: float 15s infinite linear;
        }
        
        @keyframes float {
            0% {
                transform: translateY(100vh) rotate(0deg);
            }
            100% {
                transform: translateY(-100px) rotate(360deg);
            }
        }
        
        /* Адаптивность */
        @media (max-width: 480px) {
            .login-card {
                padding: 30px 20px;
            }
            
            .card-title {
                font-size: 24px;
            }
            
            .logo-text {
                font-size: 36px;
            }
            
            .card-icon {
                width: 60px;
                height: 60px;
                font-size: 24px;
            }
        }
    </style>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <!-- Эффект частиц -->
    <div class="particles" id="particles"></div>
    
    <div class="container">
        <div class="logo">
            <div class="logo-text">CINEMAX</div>
            <div class="logo-subtitle">ВХОД В СИСТЕМУ</div>
        </div>
        
        <div class="login-card">
            <div class="card-header">
                <div class="card-icon">
                    <i class="fas fa-film"></i>
                </div>
                <h2 class="card-title">Добро пожаловать!</h2>
                <p class="card-subtitle">Войдите в свой аккаунт для продолжения</p>
            </div>
            
            <?php if ($error): ?>
                <div class="error-message">
                    <i class="fas fa-exclamation-circle error-icon"></i>
                    <?php echo htmlspecialchars($error); ?>
                </div>
            <?php endif; ?>
            
            <form method="POST" action="">
                <div class="form-group">
                    <label class="form-label">Логин или Email</label>
                    <div class="input-wrapper">
                        <i class="fas fa-user input-icon"></i>
                        <input type="text" 
                               name="login" 
                               class="form-input" 
                               placeholder="Введите логин или email" 
                               required
                               autofocus>
                    </div>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Пароль</label>
                    <div class="input-wrapper">
                        <i class="fas fa-lock input-icon"></i>
                        <input type="password" 
                               name="password" 
                               class="form-input" 
                               placeholder="Введите пароль" 
                               required>
                    </div>
                </div>
                
                <div class="form-options">
                    <label class="remember-me">
                        <input type="checkbox" class="remember-checkbox">
                        Запомнить меня
                    </label>
                    
                </div>
                
                <button type="submit" class="submit-btn">
                    <i class="fas fa-sign-in-alt"></i>
                    Войти в систему
                </button>
            </form>
            
            <div class="links-section">
                <p class="link-text">Нет аккаунта?</p>
                <a href="register.php" class="action-link">
                    <i class="fas fa-user-plus"></i>
                    Создать новый аккаунт
                </a>
                
                <a href="index.php" class="home-link">
                    <i class="fas fa-arrow-left"></i>
                    Вернуться на главную
                </a>
            </div>
        </div>
    </div>

    <script>
        // Создание эффекта частиц
        document.addEventListener('DOMContentLoaded', function() {
            const particlesContainer = document.getElementById('particles');
            const particleCount = 20;
            
            for (let i = 0; i < particleCount; i++) {
                const particle = document.createElement('div');
                particle.className = 'particle';
                
                // Случайные параметры
                const size = Math.random() * 10 + 5;
                const left = Math.random() * 100;
                const delay = Math.random() * 15;
                const duration = Math.random() * 10 + 15;
                const opacity = Math.random() * 0.5 + 0.1;
                
                particle.style.width = `${size}px`;
                particle.style.height = `${size}px`;
                particle.style.left = `${left}%`;
                particle.style.animationDelay = `${delay}s`;
                particle.style.animationDuration = `${duration}s`;
                particle.style.opacity = opacity;
                
                particlesContainer.appendChild(particle);
            }
            
            // Анимация фокуса на инпутах
            const inputs = document.querySelectorAll('.form-input');
            inputs.forEach(input => {
                input.addEventListener('focus', function() {
                    this.parentElement.style.transform = 'scale(1.02)';
                });
                
                input.addEventListener('blur', function() {
                    this.parentElement.style.transform = 'scale(1)';
                });
            });
            
            // Показ/скрытие пароля
            const passwordInput = document.querySelector('input[name="password"]');
            const lockIcon = document.querySelector('.fa-lock');
            
            lockIcon.addEventListener('click', function() {
                if (passwordInput.type === 'password') {
                    passwordInput.type = 'text';
                    this.classList.remove('fa-lock');
                    this.classList.add('fa-unlock');
                } else {
                    passwordInput.type = 'password';
                    this.classList.remove('fa-unlock');
                    this.classList.add('fa-lock');
                }
            });
            
            // Добавляем подсказку для иконки замка
            lockIcon.style.cursor = 'pointer';
            lockIcon.title = 'Показать/скрыть пароль';
        });
    </script>
</body>
</html>