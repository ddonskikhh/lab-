<?php
// index.php
require_once 'config.php';
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CINEMAX - Главная</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Arial', sans-serif;
        }
        
        body {
            background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
            color: #fff;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            align-items: center;
            padding: 20px;
            position: relative;
            overflow-x: hidden;
        }
        
        body::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: url('https://images.unsplash.com/photo-1489599809516-9827b6d1cf13?auto=format&fit=crop&w=1200&q=80') center/cover;
            opacity: 0.1;
            z-index: -1;
        }
        
        .container {
            max-width: 1200px;
            width: 100%;
            text-align: center;
            position: relative;
            z-index: 1;
        }
        
        .logo {
            font-size: 72px;
            font-weight: 900;
            color: #ffd700;
            margin: 30px 0 20px;
            text-transform: uppercase;
            letter-spacing: 4px;
            text-shadow: 0 0 30px rgba(255, 215, 0, 0.5);
            animation: glow 2.5s ease-in-out infinite alternate;
            background: linear-gradient(135deg, #ffd700 0%, #ffed4e 50%, #ffd700 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        
        @keyframes glow {
            0% {
                text-shadow: 0 0 10px rgba(255, 215, 0, 0.3);
            }
            50% {
                text-shadow: 0 0 25px rgba(255, 215, 0, 0.7);
            }
            100% {
                text-shadow: 0 0 10px rgba(255, 215, 0, 0.3);
            }
        }
        
        h1 {
            font-size: 42px;
            color: #fff;
            margin-bottom: 30px;
            text-shadow: 2px 2px 8px rgba(0,0,0,0.5);
            font-weight: 300;
        }
        
        .subtitle {
            font-size: 20px;
            color: #ccc;
            margin-bottom: 60px;
            max-width: 800px;
            margin-left: auto;
            margin-right: auto;
            line-height: 1.8;
            letter-spacing: 0.5px;
        }
        
        /* Информация о пользователе */
        .user-info {
            background: rgba(255, 255, 255, 0.05);
            backdrop-filter: blur(15px);
            border: 1px solid rgba(255, 215, 0, 0.2);
            border-radius: 20px;
            padding: 40px;
            margin: 50px auto;
            max-width: 600px;
            text-align: left;
            transition: all 0.5s cubic-bezier(0.175, 0.885, 0.32, 1.275);
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
        }
        
        .user-info:hover {
            transform: translateY(-10px) scale(1.01);
            box-shadow: 0 20px 50px rgba(255, 215, 0, 0.2);
            border-color: rgba(255, 215, 0, 0.5);
        }
        
        .user-header {
            display: flex;
            align-items: center;
            gap: 20px;
            margin-bottom: 30px;
            padding-bottom: 20px;
            border-bottom: 1px solid rgba(255, 215, 0, 0.3);
        }
        
        .user-icon {
            width: 70px;
            height: 70px;
            background: linear-gradient(135deg, #ffd700 0%, #ffed4e 100%);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 28px;
            color: #000;
            box-shadow: 0 8px 20px rgba(255, 215, 0, 0.4);
            transition: transform 0.5s;
        }
        
        .user-info:hover .user-icon {
            transform: rotate(360deg);
        }
        
        .user-details {
            flex: 1;
        }
        
        .user-name {
            font-size: 24px;
            font-weight: bold;
            color: #ffd700;
            margin-bottom: 8px;
            letter-spacing: 1px;
        }
        
        .user-role {
            display: inline-block;
            padding: 8px 18px;
            background: linear-gradient(135deg, rgba(255, 215, 0, 0.1) 0%, rgba(255, 215, 0, 0.05) 100%);
            border: 1px solid rgba(255, 215, 0, 0.3);
            border-radius: 25px;
            font-size: 13px;
            color: #ffd700;
            text-transform: uppercase;
            letter-spacing: 2px;
            font-weight: bold;
            transition: all 0.3s;
        }
        
        .user-role.admin {
            background: linear-gradient(135deg, rgba(220, 53, 69, 0.1) 0%, rgba(220, 53, 69, 0.05) 100%);
            border-color: rgba(220, 53, 69, 0.3);
            color: #ff6b6b;
        }
        
        .info-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 20px;
        }
        
        .info-item {
            display: flex;
            flex-direction: column;
            gap: 8px;
            padding: 15px;
            background: rgba(255, 255, 255, 0.03);
            border-radius: 12px;
            border: 1px solid rgba(255, 255, 255, 0.05);
            transition: all 0.3s;
        }
        
        .info-item:hover {
            background: rgba(255, 215, 0, 0.05);
            border-color: rgba(255, 215, 0, 0.2);
            transform: translateY(-3px);
        }
        
        .info-label {
            font-size: 12px;
            color: #aaa;
            text-transform: uppercase;
            letter-spacing: 1.5px;
            font-weight: bold;
        }
        
        .info-value {
            font-size: 16px;
            color: #fff;
            font-weight: 500;
        }
        
        /* Ссылки */
        .auth-links {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 25px;
            margin: 60px 0;
            max-width: 1200px;
            margin-left: auto;
            margin-right: auto;
        }
        
        .auth-link {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            text-decoration: none;
            background: rgba(255, 255, 255, 0.05);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 20px;
            padding: 40px 30px;
            transition: all 0.5s cubic-bezier(0.175, 0.885, 0.32, 1.275);
            height: 220px;
            position: relative;
            overflow: hidden;
        }
        
        .auth-link::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: linear-gradient(135deg, 
                rgba(255, 215, 0, 0.1) 0%, 
                rgba(255, 215, 0, 0) 100%);
            opacity: 0;
            transition: opacity 0.5s;
        }
        
        .auth-link:hover {
            transform: translateY(-15px) scale(1.03);
            border-color: #ffd700;
            box-shadow: 0 25px 60px rgba(255, 215, 0, 0.2);
        }
        
        .auth-link:hover::before {
            opacity: 1;
        }
        
        .auth-icon {
            font-size: 48px;
            margin-bottom: 25px;
            color: #ffd700;
            transition: all 0.5s;
        }
        
        .auth-link:hover .auth-icon {
            transform: scale(1.3) rotate(10deg);
            filter: drop-shadow(0 5px 15px rgba(255, 215, 0, 0.5));
        }
        
        .auth-text {
            font-size: 22px;
            font-weight: bold;
            color: #fff;
            margin-bottom: 12px;
            letter-spacing: 1px;
        }
        
        .auth-description {
            font-size: 14px;
            color: #aaa;
            text-align: center;
            max-width: 220px;
            line-height: 1.6;
        }
        
        .logout {
            border-color: rgba(220, 53, 69, 0.3);
        }
        
        .logout:hover {
            border-color: #ff6b6b;
            box-shadow: 0 25px 60px rgba(220, 53, 69, 0.2);
        }
        
        .logout .auth-icon {
            color: #ff6b6b;
        }
        
        .admin {
            border-color: rgba(0, 123, 255, 0.3);
        }
        
        .admin:hover {
            border-color: #4dabf7;
            box-shadow: 0 25px 60px rgba(0, 123, 255, 0.2);
        }
        
        .admin .auth-icon {
            color: #4dabf7;
        }
        
        /* Сообщение для гостей */
        .guest-message {
            font-size: 22px;
            color: #ccc;
            margin: 50px 0;
            text-align: center;
            line-height: 1.8;
            max-width: 700px;
            margin-left: auto;
            margin-right: auto;
            padding: 30px;
            background: rgba(255, 255, 255, 0.03);
            border-radius: 15px;
            border: 1px solid rgba(255, 255, 255, 0.1);
        }
        
        /* Кнопки для гостей */
        .guest-links {
            display: flex;
            gap: 25px;
            justify-content: center;
            flex-wrap: wrap;
            margin-top: 40px;
            margin-bottom: 80px;
        }
        
        .guest-button {
            display: inline-flex;
            align-items: center;
            gap: 12px;
            padding: 18px 35px;
            text-decoration: none;
            border-radius: 50px;
            font-size: 18px;
            font-weight: bold;
            transition: all 0.5s cubic-bezier(0.175, 0.885, 0.32, 1.275);
            min-width: 220px;
            justify-content: center;
            letter-spacing: 1px;
        }
        
        .guest-button.login {
            background: linear-gradient(135deg, #ffd700 0%, #ffed4e 100%);
            color: #000;
            border: 2px solid transparent;
            box-shadow: 0 10px 25px rgba(255, 215, 0, 0.3);
        }
        
        .guest-button.login:hover {
            background: transparent;
            border-color: #ffd700;
            color: #ffd700;
            transform: translateY(-8px) scale(1.05);
            box-shadow: 0 20px 40px rgba(255, 215, 0, 0.4);
        }
        
        .guest-button.register {
            background: transparent;
            border: 2px solid #ffd700;
            color: #ffd700;
            box-shadow: 0 10px 25px rgba(255, 215, 0, 0.1);
        }
        
        .guest-button.register:hover {
            background: rgba(255, 215, 0, 0.1);
            border-color: #ffed4e;
            transform: translateY(-8px) scale(1.05);
            box-shadow: 0 20px 40px rgba(255, 215, 0, 0.3);
        }
        
        /* Дополнительные услуги */
        .services-preview {
            margin-top: 80px;
            padding-top: 60px;
            border-top: 1px solid rgba(255, 255, 255, 0.1);
        }
        
        .services-preview h2 {
            font-size: 36px;
            color: #ffd700;
            margin-bottom: 50px;
            text-transform: uppercase;
            letter-spacing: 3px;
            position: relative;
            display: inline-block;
        }
        
        .services-preview h2::after {
            content: '';
            position: absolute;
            bottom: -15px;
            left: 50%;
            transform: translateX(-50%);
            width: 100px;
            height: 3px;
            background: linear-gradient(90deg, transparent, #ffd700, transparent);
            border-radius: 2px;
        }
        
        .services-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 25px;
            max-width: 1200px;
            margin: 0 auto;
            margin-bottom: 40px;
        }
        
        .service-preview {
            background: linear-gradient(135deg, rgba(255, 255, 255, 0.05) 0%, rgba(255, 255, 255, 0.02) 100%);
            border-radius: 15px;
            padding: 30px 20px;
            transition: all 0.5s cubic-bezier(0.175, 0.885, 0.32, 1.275);
            border: 1px solid rgba(255, 255, 255, 0.1);
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 15px;
        }
        
        .service-preview:hover {
            transform: translateY(-10px) scale(1.05);
            background: linear-gradient(135deg, rgba(255, 215, 0, 0.1) 0%, rgba(255, 215, 0, 0.05) 100%);
            border-color: rgba(255, 215, 0, 0.3);
            box-shadow: 0 20px 40px rgba(255, 215, 0, 0.2);
        }
        
        .service-icon {
            font-size: 40px;
            color: #ffd700;
            transition: all 0.5s;
            filter: drop-shadow(0 5px 15px rgba(255, 215, 0, 0.3));
        }
        
        .service-preview:hover .service-icon {
            transform: scale(1.3) rotate(15deg);
            filter: drop-shadow(0 10px 20px rgba(255, 215, 0, 0.5));
        }
        
        .service-name {
            font-size: 16px;
            color: #fff;
            font-weight: 500;
            letter-spacing: 1px;
        }
        
        .services-link {
            display: inline-block;
            margin-top: 40px;
            padding: 15px 40px;
            background: transparent;
            border: 2px solid #ffd700;
            border-radius: 50px;
            color: #ffd700;
            text-decoration: none;
            font-size: 18px;
            font-weight: bold;
            transition: all 0.5s cubic-bezier(0.175, 0.885, 0.32, 1.275);
            letter-spacing: 1px;
        }
        
        .services-link:hover {
            background: rgba(255, 215, 0, 0.1);
            transform: translateY(-5px) scale(1.05);
            box-shadow: 0 15px 30px rgba(255, 215, 0, 0.3);
            padding: 15px 50px;
        }
        
        /* Адаптивность */
        @media (max-width: 1200px) {
            .services-grid {
                grid-template-columns: repeat(2, 1fr);
                max-width: 800px;
            }
        }
        
        @media (max-width: 992px) {
            .logo {
                font-size: 56px;
            }
            
            h1 {
                font-size: 36px;
            }
            
            .auth-links {
                grid-template-columns: repeat(2, 1fr);
            }
            
            .info-grid {
                grid-template-columns: 1fr;
            }
            
            .guest-links {
                flex-direction: column;
                align-items: center;
            }
            
            .guest-button {
                width: 100%;
                max-width: 350px;
            }
        }
        
        @media (max-width: 768px) {
            .logo {
                font-size: 48px;
                letter-spacing: 3px;
            }
            
            h1 {
                font-size: 28px;
            }
            
            .subtitle {
                font-size: 18px;
                padding: 0 20px;
            }
            
            .auth-links {
                grid-template-columns: 1fr;
                max-width: 400px;
            }
            
            .services-grid {
                grid-template-columns: 1fr;
                max-width: 400px;
            }
            
            .user-info {
                padding: 30px;
                margin: 30px 20px;
            }
            
            .auth-link {
                height: 200px;
                padding: 30px 20px;
            }
            
            .user-header {
                flex-direction: column;
                text-align: center;
                gap: 15px;
            }
        }
        
        @media (max-width: 480px) {
            .logo {
                font-size: 36px;
                letter-spacing: 2px;
            }
            
            h1 {
                font-size: 24px;
            }
            
            .subtitle {
                font-size: 16px;
            }
            
            .user-info {
                padding: 25px;
            }
            
            .guest-button {
                padding: 15px 25px;
                font-size: 16px;
            }
            
            .services-preview h2 {
                font-size: 28px;
            }
        }
    </style>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <div class="container">
        <div class="logo">CINEMAX</div>
        <h1>Добро пожаловать в мир большого кино!</h1>
        <p class="subtitle">Погрузитесь в атмосферу современного кинематографа с передовыми технологиями и непревзойденным комфортом. Эксклюзивные услуги, премиальные залы и незабываемые впечатления ждут вас!</p>
        
        <?php if (isLoggedIn()): ?>
            <?php $user = getCurrentUser(); ?>
            
            <div class="user-info">
                <div class="user-header">
                    <div class="user-icon">
                        <i class="fas fa-user"></i>
                    </div>
                    <div class="user-details">
                        <div class="user-name"><?php echo htmlspecialchars($user['login'] ?? 'Пользователь'); ?></div>
                        <div class="user-role <?php echo (isset($user['role']) && $user['role'] === 'admin') ? 'admin' : ''; ?>">
                            <?php 
                            if (isset($user['role'])) {
                                echo $user['role'] === 'admin' ? 'Администратор' : 'Пользователь';
                            } else {
                                echo 'Пользователь';
                            }
                            ?>
                        </div>
                    </div>
                </div>
                
                <div class="info-grid">
                    <div class="info-item">
                        <span class="info-label">ID</span>
                        <span class="info-value">#<?php echo $user['id']; ?></span>
                    </div>
                    <div class="info-item">
                        <span class="info-label">Email</span>
                        <span class="info-value"><?php echo htmlspecialchars($user['email'] ?? 'Не указан'); ?></span>
                    </div>
                    <div class="info-item">
                        <span class="info-label">Статус</span>
                        <span class="info-value" style="color: #28a745;">Активный ✓</span>
                    </div>
                    <div class="info-item">
                        <span class="info-label">Регистрация</span>
                        <span class="info-value"><?php echo date('d.m.Y', strtotime($user['created_at'] ?? 'now')); ?></span>
                    </div>
                </div>
            </div>
            
            <div class="auth-links">
                <a href="services.php" class="auth-link">
                    <i class="fas fa-film auth-icon"></i>
                    <span class="auth-text">Наши услуги</span>
                    <span class="auth-description">Откройте мир премиального кино и уникальных возможностей</span>
                </a>
                
                <a href="profile.php" class="auth-link">
                    <i class="fas fa-user-cog auth-icon"></i>
                    <span class="auth-text">Мой профиль</span>
                    <span class="auth-description">Управляйте вашим аккаунтом, настройками и данными</span>
                </a>
                
                <?php if (isAdmin()): ?>
                    <a href="admin.php" class="auth-link admin">
                        <i class="fas fa-crown auth-icon"></i>
                        <span class="auth-text">Админ-панель</span>
                        <span class="auth-description">Полный контроль над системой и пользователями</span>
                    </a>
                <?php endif; ?>
                
                <a href="logout.php" class="auth-link logout">
                    <i class="fas fa-sign-out-alt auth-icon"></i>
                    <span class="auth-text">Выйти</span>
                    <span class="auth-description">Завершите текущий сеанс работы с системой</span>
                </a>
            </div>
            
        <?php else: ?>
            <div class="guest-message">
                <p>Для доступа ко всем возможностям кинотеатра, бронирования билетов и получения специальных предложений, пожалуйста, войдите в систему или создайте новый аккаунт</p>
            </div>
            
            <div class="guest-links">
                <a href="login.php" class="guest-button login">
                    <i class="fas fa-sign-in-alt"></i>
                    Войти в аккаунт
                </a>
                <a href="register.php" class="guest-button register">
                    <i class="fas fa-user-plus"></i>
                    Создать аккаунт
                </a>
            </div>
            
            <div class="services-preview">
                <h2>Наши услуги</h2>
                <div class="services-grid">
                    <div class="service-preview">
                        <i class="fas fa-theater-masks service-icon"></i>
                        <div class="service-name">Премиум залы</div>
                    </div>
                    <div class="service-preview">
                        <i class="fas fa-utensils service-icon"></i>
                        <div class="service-name">Еда и напитки</div>
                    </div>
                    <div class="service-preview">
                        <i class="fas fa-crown service-icon"></i>
                        <div class="service-name">VIP обслуживание</div>
                    </div>
                    <div class="service-preview">
                        <i class="fas fa-vr-cardboard service-icon"></i>
                        <div class="service-name">3D и IMAX</div>
                    </div>
                    <div class="service-preview">
                        <i class="fas fa-child service-icon"></i>
                        <div class="service-name">Детская зона</div>
                    </div>
                    <div class="service-preview">
                        <i class="fas fa-ticket-alt service-icon"></i>
                        <div class="service-name">Кинокарты</div>
                    </div>
                    <div class="service-preview">
                        <i class="fas fa-glass-cheers service-icon"></i>
                        <div class="service-name">Корпоративы</div>
                    </div>
                    <div class="service-preview">
                        <i class="fas fa-heart service-icon"></i>
                        <div class="service-name">Романтические вечера</div>
                    </div>
                </div>
                <a href="services.php" class="services-link">
                    <i class="fas fa-arrow-right"></i> Посмотреть все услуги
                </a>
            </div>
        <?php endif; ?>
    </div>

    <script>
        // Анимация появления элементов
        document.addEventListener('DOMContentLoaded', function() {
            const elements = document.querySelectorAll('.user-info, .auth-link, .guest-button, .service-preview');
            
            elements.forEach((el, index) => {
                el.style.opacity = '0';
                el.style.transform = 'translateY(30px)';
                el.style.transition = 'opacity 0.6s, transform 0.6s cubic-bezier(0.175, 0.885, 0.32, 1.275)';
                el.style.transitionDelay = (index * 0.1) + 's';
                
                setTimeout(() => {
                    el.style.opacity = '1';
                    el.style.transform = 'translateY(0)';
                }, 50);
            });
            
            // Эффект параллакса для фона
            document.addEventListener('mousemove', function(e) {
                const x = (e.clientX / window.innerWidth - 0.5) * 40;
                const y = (e.clientY / window.innerHeight - 0.5) * 40;
                
                document.querySelector('body::before').style.transform = `translate(${x}px, ${y}px)`;
            });
            
            // Плавный скролл для якорей
            document.querySelectorAll('a[href^="#"]').forEach(anchor => {
                anchor.addEventListener('click', function(e) {
                    e.preventDefault();
                    const target = document.querySelector(this.getAttribute('href'));
                    if (target) {
                        target.scrollIntoView({
                            behavior: 'smooth',
                            block: 'start'
                        });
                    }
                });
            });
            
            // Анимация при наведении на услуги
            const servicePreviews = document.querySelectorAll('.service-preview');
            servicePreviews.forEach((service, index) => {
                service.style.transitionDelay = (index * 0.05) + 's';
                
                service.addEventListener('mouseenter', function() {
                    const icon = this.querySelector('.service-icon');
                    icon.style.transform = 'scale(1.3) rotate(15deg)';
                    icon.style.filter = 'drop-shadow(0 10px 20px rgba(255, 215, 0, 0.5))';
                });
                
                service.addEventListener('mouseleave', function() {
                    const icon = this.querySelector('.service-icon');
                    icon.style.transform = 'scale(1) rotate(0)';
                    icon.style.filter = 'drop-shadow(0 5px 15px rgba(255, 215, 0, 0.3))';
                });
            });
            
            // Анимация кнопок для гостей
            const guestButtons = document.querySelectorAll('.guest-button');
            guestButtons.forEach((button, index) => {
                button.style.animationDelay = (index * 0.2) + 's';
            });
        });
    </script>
</body>
</html>