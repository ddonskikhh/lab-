<?php
// profile.php
require_once 'config.php';
requireLogin();

$user = getCurrentUser();
$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    
    try {
        $db = getDB();
        
        if (!empty($password)) {
            if ($password !== $confirm_password) {
                $error = 'Пароли не совпадают';
            } elseif (strlen($password) < 6) {
                $error = 'Пароль должен быть не менее 6 символов';
            } else {
                $hashed_password = hashPassword($password);
                $stmt = $db->prepare("UPDATE users SET email = ?, password = ? WHERE id = ?");
                $stmt->execute([$email, $hashed_password, $user['id']]);
                $_SESSION['email'] = $email;
                $success = 'Данные успешно обновлены';
            }
        } else {
            $stmt = $db->prepare("UPDATE users SET email = ? WHERE id = ?");
            $stmt->execute([$email, $user['id']]);
            $_SESSION['email'] = $email;
            $success = 'Email успешно обновлен';
        }
    } catch(PDOException $e) {
        $error = 'Ошибка при обновлении: ' . $e->getMessage();
    }
}

// Получение актуальных данных пользователя
try {
    $db = getDB();
    $stmt = $db->prepare("SELECT login, email, created_at FROM users WHERE id = ?");
    $stmt->execute([$user['id']]);
    $userData = $stmt->fetch();
    
    if (!$userData) {
        $error = 'Пользователь не найден';
        $userData = ['login' => '', 'email' => '', 'created_at' => ''];
    }
} catch(PDOException $e) {
    $error = 'Ошибка загрузки данных: ' . $e->getMessage();
    $userData = ['login' => '', 'email' => '', 'created_at' => ''];
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CINEMAX - Мой профиль</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Arial', sans-serif;
        }
        
        body {
            background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
            color: #fff;
            min-height: 100vh;
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }
        
        /* Навигация */
        .navbar {
            background: rgba(0, 0, 0, 0.8);
            padding: 15px 0;
            position: sticky;
            top: 0;
            z-index: 1000;
            backdrop-filter: blur(10px);
        }
        
        .nav-container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .logo {
            font-size: 24px;
            font-weight: bold;
            color: #ffd700;
            text-decoration: none;
        }
        
        .nav-links {
            display: flex;
            gap: 30px;
            align-items: center;
        }
        
        .nav-links a {
            color: #fff;
            text-decoration: none;
            font-size: 16px;
            transition: color 0.3s;
            position: relative;
        }
        
        .nav-links a:hover {
            color: #ffd700;
        }
        
        .nav-links a.active {
            color: #ffd700;
        }
        
        .nav-links a.active::after {
            content: '';
            position: absolute;
            bottom: -5px;
            left: 0;
            width: 100%;
            height: 2px;
            background: #ffd700;
        }
        
        /* Заголовок */
        .header {
            text-align: center;
            padding: 60px 0 40px;
            margin-bottom: 40px;
        }
        
        .header h1 {
            font-size: 48px;
            margin-bottom: 15px;
            color: #ffd700;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.5);
        }
        
        .header p {
            font-size: 18px;
            max-width: 800px;
            margin: 0 auto;
            line-height: 1.6;
            opacity: 0.9;
        }
        
        /* Основной контент */
        .profile-content {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 40px;
            margin-bottom: 60px;
        }
        
        @media (max-width: 900px) {
            .profile-content {
                grid-template-columns: 1fr;
            }
        }
        
        /* Карточка информации */
        .info-card {
            background: rgba(255, 255, 255, 0.05);
            border-radius: 15px;
            padding: 40px;
            border: 1px solid rgba(255, 215, 0, 0.1);
            transition: transform 0.3s, box-shadow 0.3s;
        }
        
        .info-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 20px 40px rgba(255, 215, 0, 0.1);
            border-color: rgba(255, 215, 0, 0.3);
        }
        
        .user-header {
            display: flex;
            align-items: center;
            gap: 20px;
            margin-bottom: 30px;
            padding-bottom: 20px;
            border-bottom: 1px solid rgba(255, 215, 0, 0.2);
        }
        
        .user-avatar {
            width: 80px;
            height: 80px;
            background: linear-gradient(135deg, #ffd700 0%, #ffed4e 100%);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 32px;
            color: #000;
            box-shadow: 0 10px 20px rgba(255, 215, 0, 0.3);
        }
        
        .user-info {
            flex: 1;
        }
        
        .user-name {
            font-size: 24px;
            font-weight: bold;
            color: #ffd700;
            margin-bottom: 5px;
        }
        
        .user-role {
            display: inline-block;
            padding: 5px 15px;
            background: rgba(255, 215, 0, 0.1);
            border: 1px solid rgba(255, 215, 0, 0.3);
            border-radius: 20px;
            font-size: 12px;
            color: #ffd700;
            text-transform: uppercase;
            letter-spacing: 1px;
        }
        
        .user-role.admin {
            background: rgba(220, 53, 69, 0.1);
            border-color: rgba(220, 53, 69, 0.3);
            color: #dc3545;
        }
        
        /* Список информации */
        .info-list {
            display: grid;
            gap: 15px;
        }
        
        .info-item {
            display: flex;
            justify-content: space-between;
            padding: 12px 0;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }
        
        .info-label {
            color: #aaa;
            font-size: 14px;
            text-transform: uppercase;
            letter-spacing: 1px;
        }
        
        .info-value {
            color: #fff;
            font-weight: 500;
            text-align: right;
        }
        
        /* Форма редактирования */
        .form-card {
            background: rgba(255, 255, 255, 0.05);
            border-radius: 15px;
            padding: 40px;
            border: 1px solid rgba(255, 215, 0, 0.1);
        }
        
        .form-title {
            font-size: 24px;
            color: #ffd700;
            margin-bottom: 30px;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .form-group {
            margin-bottom: 25px;
        }
        
        .form-label {
            display: block;
            margin-bottom: 10px;
            color: #ccc;
            font-size: 14px;
            font-weight: 500;
            text-transform: uppercase;
            letter-spacing: 1px;
        }
        
        .input-wrapper {
            position: relative;
        }
        
        .form-input {
            width: 100%;
            padding: 15px 20px;
            background: rgba(255, 255, 255, 0.08);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 10px;
            color: #fff;
            font-size: 16px;
            transition: all 0.3s;
        }
        
        .form-input:focus {
            outline: none;
            border-color: #ffd700;
            background: rgba(255, 255, 255, 0.12);
            box-shadow: 0 0 0 3px rgba(255, 215, 0, 0.1);
        }
        
        .form-input::placeholder {
            color: #777;
        }
        
        .input-icon {
            position: absolute;
            right: 20px;
            top: 50%;
            transform: translateY(-50%);
            color: #ffd700;
            font-size: 18px;
            cursor: pointer;
        }
        
        .form-hint {
            font-size: 12px;
            color: #777;
            margin-top: 8px;
            display: block;
        }
        
        /* Кнопка */
        .submit-btn {
            width: 100%;
            padding: 16px;
            background: linear-gradient(135deg, #ffd700 0%, #ffed4e 100%);
            border: none;
            border-radius: 10px;
            color: #000;
            font-size: 16px;
            font-weight: bold;
            cursor: pointer;
            transition: all 0.3s;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            margin-top: 20px;
        }
        
        .submit-btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 10px 25px rgba(255, 215, 0, 0.4);
        }
        
        .submit-btn:active {
            transform: translateY(-1px);
        }
        
        /* Сообщения */
        .message {
            padding: 15px 20px;
            border-radius: 10px;
            margin-bottom: 25px;
            display: flex;
            align-items: center;
            gap: 10px;
            animation: slideIn 0.5s ease;
        }
        
        @keyframes slideIn {
            from {
                opacity: 0;
                transform: translateY(-20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        .error-message {
            background: rgba(220, 53, 69, 0.1);
            border: 1px solid rgba(220, 53, 69, 0.3);
            color: #ff6b6b;
        }
        
        .success-message {
            background: rgba(40, 167, 69, 0.1);
            border: 1px solid rgba(40, 167, 69, 0.3);
            color: #28a745;
        }
        
        /* Дополнительные ссылки */
        .quick-links {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-top: 40px;
        }
        
        .quick-link {
            background: rgba(255, 255, 255, 0.05);
            border: 1px solid rgba(255, 215, 0, 0.2);
            border-radius: 10px;
            padding: 20px;
            text-align: center;
            text-decoration: none;
            color: #fff;
            transition: all 0.3s;
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 15px;
        }
        
        .quick-link:hover {
            background: rgba(255, 215, 0, 0.1);
            border-color: #ffd700;
            transform: translateY(-5px);
        }
        
        .link-icon {
            font-size: 32px;
            color: #ffd700;
        }
        
        .link-text {
            font-weight: 500;
        }
        
        /* Футер */
        .footer {
            background: rgba(0, 0, 0, 0.9);
            padding: 40px 0;
            margin-top: 60px;
            border-top: 1px solid rgba(255, 215, 0, 0.1);
        }
        
        .footer-content {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 40px;
        }
        
        .footer-section h3 {
            color: #ffd700;
            margin-bottom: 20px;
            font-size: 20px;
        }
        
        .footer-links {
            list-style: none;
        }
        
        .footer-links li {
            margin-bottom: 10px;
        }
        
        .footer-links a {
            color: #ccc;
            text-decoration: none;
            transition: color 0.3s;
        }
        
        .footer-links a:hover {
            color: #ffd700;
        }
        
        .contact-info {
            color: #ccc;
            line-height: 1.6;
        }
        
        .copyright {
            text-align: center;
            padding-top: 30px;
            border-top: 1px solid rgba(255, 255, 255, 0.1);
            color: #666;
            font-size: 14px;
            margin-top: 30px;
        }
        
        /* Анимация появления */
        .info-card, .form-card, .quick-link {
            opacity: 0;
            transform: translateY(30px);
            animation: fadeInUp 0.8s ease forwards;
        }
        
        @keyframes fadeInUp {
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        /* Адаптивность */
        @media (max-width: 768px) {
            .header h1 {
                font-size: 36px;
            }
            
            .nav-container {
                flex-direction: column;
                gap: 15px;
            }
            
            .nav-links {
                flex-wrap: wrap;
                justify-content: center;
            }
            
            .user-header {
                flex-direction: column;
                text-align: center;
            }
            
            .info-card, .form-card {
                padding: 25px;
            }
        }
        
        @media (max-width: 480px) {
            .header h1 {
                font-size: 28px;
            }
            
            .user-avatar {
                width: 60px;
                height: 60px;
                font-size: 24px;
            }
            
            .user-name {
                font-size: 20px;
            }
            
            .quick-links {
                grid-template-columns: 1fr;
            }
        }
    </style>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <!-- Навигация -->
    <nav class="navbar">
        <div class="nav-container">
            <a href="index.php" class="logo">CINEMAX</a>
            <div class="nav-links">
                <a href="index.php">Главная</a>
                <a href="services.php">Услуги</a>
                <a href="profile.php" class="active">Профиль</a>
                <?php if (isAdmin()): ?>
                    <a href="admin.php"><i class="fas fa-crown"></i> Админ</a>
                <?php endif; ?>
                <a href="logout.php"><i class="fas fa-sign-out-alt"></i> Выйти</a>
            </div>
        </div>
    </nav>

    <div class="container">
        <!-- Заголовок -->
        <header class="header">
            <h1><i class="fas fa-user-circle"></i> Мой профиль</h1>
            <p>Управляйте своими данными и настройками аккаунта</p>
        </header>

        <!-- Основной контент -->
        <div class="profile-content">
            <!-- Левая колонка: Информация о пользователе -->
            <div class="info-card">
                <div class="user-header">
                    <div class="user-avatar">
                        <i class="fas fa-user"></i>
                    </div>
                    <div class="user-info">
                        <div class="user-name"><?php echo htmlspecialchars($userData['login'] ?? ''); ?></div>
                        <div class="user-role <?php echo isAdmin() ? 'admin' : ''; ?>">
                            <?php echo isAdmin() ? 'Администратор' : 'Пользователь'; ?>
                        </div>
                    </div>
                </div>
                
                <div class="info-list">
                    <div class="info-item">
                        <span class="info-label">Логин</span>
                        <span class="info-value"><?php echo htmlspecialchars($userData['login'] ?? ''); ?></span>
                    </div>
                    
                    <div class="info-item">
                        <span class="info-label">Email</span>
                        <span class="info-value"><?php echo htmlspecialchars($userData['email'] ?? ''); ?></span>
                    </div>
                    
                    <div class="info-item">
                        <span class="info-label">ID пользователя</span>
                        <span class="info-value"><?php echo $user['id']; ?></span>
                    </div>
                    
                    <div class="info-item">
                        <span class="info-label">Дата регистрации</span>
                        <span class="info-value">
                            <?php 
                            if (isset($userData['created_at']) && $userData['created_at'] != '') {
                                echo date('d.m.Y H:i', strtotime($userData['created_at']));
                            } else {
                                echo 'Не указана';
                            }
                            ?>
                        </span>
                    </div>
                    
                    <div class="info-item">
                        <span class="info-label">Статус</span>
                        <span class="info-value">Активный</span>
                    </div>
                </div>
            </div>

            <!-- Правая колонка: Форма редактирования -->
            <div class="form-card">
                <h3 class="form-title"><i class="fas fa-user-edit"></i> Редактирование профиля</h3>
                
                <?php if ($error): ?>
                    <div class="message error-message">
                        <i class="fas fa-exclamation-circle"></i>
                        <?php echo htmlspecialchars($error); ?>
                    </div>
                <?php endif; ?>
                
                <?php if ($success): ?>
                    <div class="message success-message">
                        <i class="fas fa-check-circle"></i>
                        <?php echo htmlspecialchars($success); ?>
                    </div>
                <?php endif; ?>
                
                <form method="POST" action="">
                    <div class="form-group">
                        <label class="form-label">Email адрес</label>
                        <div class="input-wrapper">
                            <input type="email" 
                                   name="email" 
                                   class="form-input" 
                                   value="<?php echo htmlspecialchars($userData['email'] ?? ''); ?>" 
                                   required
                                   placeholder="Введите новый email">
                            <i class="fas fa-envelope input-icon"></i>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">Новый пароль</label>
                        <div class="input-wrapper">
                            <input type="password" 
                                   name="password" 
                                   id="password"
                                   class="form-input" 
                                   placeholder="Оставьте пустым, если не хотите менять"
                                   autocomplete="new-password">
                            <i class="fas fa-lock input-icon" id="togglePassword"></i>
                        </div>
                        <span class="form-hint">Минимум 6 символов</span>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">Подтвердите пароль</label>
                        <div class="input-wrapper">
                            <input type="password" 
                                   name="confirm_password" 
                                   id="confirmPassword"
                                   class="form-input" 
                                   placeholder="Повторите новый пароль"
                                   autocomplete="new-password">
                            <i class="fas fa-lock input-icon" id="toggleConfirmPassword"></i>
                        </div>
                    </div>
                    
                    <button type="submit" class="submit-btn">
                        <i class="fas fa-save"></i>
                        Сохранить изменения
                    </button>
                </form>
            </div>
        </div>

        <!-- Быстрые ссылки -->
        <div class="quick-links">
            <a href="services.php" class="quick-link">
                <i class="fas fa-film link-icon"></i>
                <span class="link-text">Услуги кинотеатра</span>
            </a>
            
            <a href="index.php" class="quick-link">
                <i class="fas fa-home link-icon"></i>
                <span class="link-text">На главную</span>
            </a>
            
            <?php if (isAdmin()): ?>
            <a href="admin.php" class="quick-link">
                <i class="fas fa-crown link-icon"></i>
                <span class="link-text">Админ-панель</span>
            </a>
            <?php endif; ?>
            
            <a href="logout.php" class="quick-link">
                <i class="fas fa-sign-out-alt link-icon"></i>
                <span class="link-text">Выйти из аккаунта</span>
            </a>
        </div>
    </div>

    <!-- Футер -->
    <footer class="footer">
        <div class="footer-content">
            <div class="footer-section">
                <h3>О кинотеатре</h3>
                <p class="contact-info">
                    CINEMAX - современный кинотеатр с передовыми технологиями и непревзойденным сервисом.
                </p>
            </div>
            
            <div class="footer-section">
                <h3>Контакты</h3>
                <p class="contact-info">
                    <i class="fas fa-map-marker-alt"></i> г. Москва, ул. Кинотеатральная, 15<br>
                    <i class="fas fa-phone"></i> +7 (495) 123-45-67<br>
                    <i class="fas fa-envelope"></i> info@cinemax.ru
                </p>
            </div>
            
            <div class="footer-section">
                <h3>Быстрые ссылки</h3>
                <ul class="footer-links">
                    <li><a href="index.php">Главная</a></li>
                    <li><a href="services.php">Услуги</a></li>
                    <li><a href="profile.php" class="active">Профиль</a></li>
                </ul>
            </div>
            
            <div class="footer-section">
                <h3>Часы работы</h3>
                <p class="contact-info">
                    Пн-Пт: 10:00 - 02:00<br>
                    Сб-Вс: 09:00 - 03:00<br>
                    Без перерывов и выходных
                </p>
            </div>
        </div>
        
        <div class="copyright">
            <p>&copy; 2024 Кинотеатр CINEMAX. Все права защищены.</p>
        </div>
    </footer>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Показать/скрыть пароль
            const passwordInput = document.getElementById('password');
            const confirmInput = document.getElementById('confirmPassword');
            const togglePassword = document.getElementById('togglePassword');
            const toggleConfirm = document.getElementById('toggleConfirmPassword');
            
            if (togglePassword) {
                togglePassword.addEventListener('click', function() {
                    if (passwordInput.type === 'password') {
                        passwordInput.type = 'text';
                        this.classList.remove('fa-lock');
                        this.classList.add('fa-unlock');
                    } else {
                        passwordInput.type = 'password';
                        this.classList.remove('fa-unlock');
                        this.classList.add('fa-lock');
                    }
                });
            }
            
            if (toggleConfirm) {
                toggleConfirm.addEventListener('click', function() {
                    if (confirmInput.type === 'password') {
                        confirmInput.type = 'text';
                        this.classList.remove('fa-lock');
                        this.classList.add('fa-unlock');
                    } else {
                        confirmInput.type = 'password';
                        this.classList.remove('fa-unlock');
                        this.classList.add('fa-lock');
                    }
                });
            }
            
            // Валидация формы
            const form = document.querySelector('form');
            if (form) {
                form.addEventListener('submit', function(e) {
                    const password = passwordInput.value;
                    const confirmPassword = confirmInput.value;
                    
                    if (password && password.length < 6) {
                        e.preventDefault();
                        alert('Пароль должен быть не менее 6 символов!');
                        return;
                    }
                    
                    if (password && password !== confirmPassword) {
                        e.preventDefault();
                        alert('Пароли не совпадают!');
                        return;
                    }
                    
                    if (password) {
                        if (!confirm('Вы уверены, что хотите изменить пароль?')) {
                            e.preventDefault();
                        }
                    }
                });
            }
            
            // Анимация при фокусе
            const inputs = document.querySelectorAll('.form-input');
            inputs.forEach(input => {
                input.addEventListener('focus', function() {
                    this.parentElement.style.transform = 'scale(1.02)';
                });
                
                input.addEventListener('blur', function() {
                    this.parentElement.style.transform = 'scale(1)';
                });
            });
            
            // Устанавливаем задержку для анимации карточек
            const cards = document.querySelectorAll('.info-card, .form-card, .quick-link');
            cards.forEach((card, index) => {
                card.style.animationDelay = `${index * 0.2}s`;
            });
        });
    </script>
</body>
</html>