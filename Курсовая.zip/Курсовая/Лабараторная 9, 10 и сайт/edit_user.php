<?php
// edit_user.php
require_once 'config.php';
requireAdmin();

$db = getDB();
$error = '';
$success = '';

// Получение ID пользователя
$edit_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if (!$edit_id) {
    header('Location: admin.php');
    exit();
}

// Получение данных пользователя
try {
    $stmt = $db->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute([$edit_id]);
    $user_to_edit = $stmt->fetch();
    
    if (!$user_to_edit) {
        header('Location: admin.php');
        exit();
    }
} catch(PDOException $e) {
    $error = 'Ошибка загрузки данных: ' . $e->getMessage();
}

// Обновление данных
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email']);
    $role = $_POST['role'];
    $password = $_POST['password'];
    
    try {
        if (!empty($password)) {
            $hashed_password = hashPassword($password);
            $stmt = $db->prepare("UPDATE users SET email = ?, role = ?, password = ? WHERE id = ?");
            $stmt->execute([$email, $role, $hashed_password, $edit_id]);
        } else {
            $stmt = $db->prepare("UPDATE users SET email = ?, role = ? WHERE id = ?");
            $stmt->execute([$email, $role, $edit_id]);
        }
        
        $success = 'Данные пользователя обновлены';
        // Обновляем локальные данные
        $user_to_edit['email'] = $email;
        $user_to_edit['role'] = $role;
    } catch(PDOException $e) {
        $error = 'Ошибка при обновлении: ' . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Редактирование пользователя</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 500px; margin: 50px auto; padding: 20px; }
        .container { background: #f9f9f9; padding: 20px; border-radius: 5px; }
        .nav { margin-bottom: 20px; }
        .nav a { text-decoration: none; color: #007bff; }
        .form-group { margin-bottom: 15px; }
        label { display: block; margin-bottom: 5px; }
        input, select { width: 100%; padding: 8px; box-sizing: border-box; }
        button { background: #007bff; color: white; padding: 10px 20px; border: none; cursor: pointer; }
        .error { color: red; margin-bottom: 10px; }
        .success { color: green; margin-bottom: 10px; }
        .info { background: #e9ecef; padding: 10px; border-radius: 5px; margin-bottom: 20px; }
    </style>
</head>
<body>
    <div class="container">
        <div class="nav">
            <a href="admin.php">← Назад к списку пользователей</a>
        </div>
        
        <h2>Редактирование пользователя: <?php echo htmlspecialchars($user_to_edit['login'] ?? ''); ?></h2>
        
        <div class="info">
            <p><strong>Логин:</strong> <?php echo htmlspecialchars($user_to_edit['login'] ?? 'Не указан'); ?></p>
            <p><strong>Дата регистрации:</strong> 
                <?php 
                if (isset($user_to_edit['created_at'])) {
                    echo date('d.m.Y H:i', strtotime($user_to_edit['created_at']));
                } else {
                    echo 'Не указана';
                }
                ?>
            </p>
        </div>
        
        <?php if ($error): ?>
            <div class="error"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>
        
        <?php if ($success): ?>
            <div class="success"><?php echo htmlspecialchars($success); ?></div>
        <?php endif; ?>
        
        <form method="POST" action="">
            <div class="form-group">
                <label>Email:</label>
                <input type="email" name="email" value="<?php echo htmlspecialchars($user_to_edit['email'] ?? ''); ?>" required>
            </div>
            
            <div class="form-group">
                <label>Роль:</label>
                <select name="role">
                    <option value="user" <?php echo ($user_to_edit['role'] ?? 'user') === 'user' ? 'selected' : ''; ?>>Пользователь</option>
                    <option value="admin" <?php echo ($user_to_edit['role'] ?? 'user') === 'admin' ? 'selected' : ''; ?>>Администратор</option>
                </select>
            </div>
            
            <div class="form-group">
                <label>Новый пароль (оставьте пустым, если не хотите менять):</label>
                <input type="password" name="password">
            </div>
            
            <button type="submit">Сохранить изменения</button>
        </form>
    </div>
</body>
</html>