<?php
// admin.php
require_once 'config.php';
requireAdmin(); // Только администраторы

$db = getDB();
$error = '';
$success = '';

// Добавление пользователя
if (isset($_POST['add_user'])) {
    $login = trim($_POST['login']);
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    $role = $_POST['role'];
    
    if (empty($login) || empty($email) || empty($password)) {
        $error = 'Все поля обязательны';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Некорректный email адрес';
    } elseif (strlen($password) < 6) {
        $error = 'Пароль должен быть не менее 6 символов';
    } elseif (strlen($login) < 3 || strlen($login) > 50) {
        $error = 'Логин должен быть от 3 до 50 символов';
    } else {
        try {
            // Проверка на существующего пользователя
            $stmt = $db->prepare("SELECT id FROM users WHERE login = ? OR email = ?");
            $stmt->execute([$login, $email]);
            
            if ($stmt->rowCount() > 0) {
                $error = 'Пользователь с таким логином или email уже существует';
            } else {
                $hashed_password = hashPassword($password);
                $stmt = $db->prepare("INSERT INTO users (login, email, password, role, created_at) VALUES (?, ?, ?, ?, NOW())");
                $stmt->execute([$login, $email, $hashed_password, $role]);
                $success = 'Пользователь успешно добавлен';
            }
        } catch(PDOException $e) {
            $error = 'Ошибка при добавлении: ' . $e->getMessage();
        }
    }
}

// Удаление пользователя
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    if ($id != $_SESSION['user_id']) { // Нельзя удалить самого себя
        try {
            $stmt = $db->prepare("DELETE FROM users WHERE id = ?");
            $stmt->execute([$id]);
            $success = 'Пользователь удален';
        } catch(PDOException $e) {
            $error = 'Ошибка при удалении: ' . $e->getMessage();
        }
    } else {
        $error = 'Нельзя удалить самого себя';
    }
}

// Изменение роли пользователя
if (isset($_POST['change_role'])) {
    $user_id = intval($_POST['user_id']);
    $new_role = $_POST['new_role'];
    
    if ($user_id != $_SESSION['user_id']) { // Нельзя изменить свою роль
        try {
            $stmt = $db->prepare("UPDATE users SET role = ? WHERE id = ?");
            $stmt->execute([$new_role, $user_id]);
            $success = 'Роль пользователя обновлена';
        } catch(PDOException $e) {
            $error = 'Ошибка при изменении роли: ' . $e->getMessage();
        }
    } else {
        $error = 'Нельзя изменить свою роль';
    }
}

// Получение статистики
$stats = [];
try {
    // Общее количество пользователей
    $stmt = $db->query("SELECT COUNT(*) as total FROM users");
    $stats['total'] = $stmt->fetch()['total'];
    
    // Количество администраторов
    $stmt = $db->query("SELECT COUNT(*) as admins FROM users WHERE role = 'admin'");
    $stats['admins'] = $stmt->fetch()['admins'];
    
    // Количество обычных пользователей
    $stats['users'] = $stats['total'] - $stats['admins'];
    
    // Последние регистрации
    $stmt = $db->query("SELECT COUNT(*) as today FROM users WHERE DATE(created_at) = CURDATE()");
    $stats['today'] = $stmt->fetch()['today'];
} catch(PDOException $e) {
    // Если возникла ошибка, просто не показываем статистику
}

// Получение списка всех пользователей с проверкой наличия поля created_at
try {
    // Проверяем, есть ли поле created_at в таблице
    $stmt = $db->query("SHOW COLUMNS FROM users LIKE 'created_at'");
    $has_created_at = $stmt->rowCount() > 0;
    
    // Проверяем, есть ли поле role в таблице
    $stmt = $db->query("SHOW COLUMNS FROM users LIKE 'role'");
    $has_role = $stmt->rowCount() > 0;
    
    // Формируем запрос в зависимости от наличия полей
    $select_fields = "id, login, email";
    if ($has_role) {
        $select_fields .= ", role";
    }
    if ($has_created_at) {
        $select_fields .= ", created_at";
    }
    
    $order_by = $has_created_at ? "ORDER BY created_at DESC" : "ORDER BY id DESC";
    
    $stmt = $db->query("SELECT $select_fields FROM users $order_by");
    $users = $stmt->fetchAll();
    
} catch(PDOException $e) {
    $error = 'Ошибка загрузки пользователей: ' . $e->getMessage();
    $users = [];
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Панель администратора</title>
    <style>
        body { 
            font-family: Arial, sans-serif; 
            margin: 0;
            padding: 20px;
            background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
            min-height: 100vh;
        }
        .container { 
            max-width: 1400px; 
            margin: 0 auto; 
            background: white;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.3);
        }
        .nav { 
            margin-bottom: 30px; 
            padding: 20px;
            border-bottom: 2px solid #e9ecef;
            display: flex;
            flex-wrap: wrap;
            gap: 15px;
            align-items: center;
            background: #f8f9fa;
            border-radius: 10px;
        }
        .nav a { 
            text-decoration: none; 
            padding: 10px 20px;
            border-radius: 8px;
            transition: all 0.3s;
            font-weight: 500;
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 15px;
        }
        .nav a:not(.site-btn):not(.logout-btn):not(.admin-btn) {
            color: #007bff;
            border: 1px solid #007bff;
            background: white;
        }
        .nav a:not(.site-btn):not(.logout-btn):not(.admin-btn):hover {
            background: #007bff;
            color: white;
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0,123,255,0.2);
        }
        .site-btn {
            background: linear-gradient(135deg, #28a745 0%, #20c997 100%);
            color: white;
            border: none;
            margin-left: auto;
        }
        .site-btn:hover {
            background: linear-gradient(135deg, #218838 0%, #17a589 100%);
            transform: translateY(-2px);
            box-shadow: 0 5px 20px rgba(40, 167, 69, 0.3);
        }
        .admin-btn {
            background: linear-gradient(135deg, #6f42c1 0%, #6610f2 100%);
            color: white;
            border: none;
        }
        .admin-btn:hover {
            background: linear-gradient(135deg, #5a32a3 0%, #520dc2 100%);
            transform: translateY(-2px);
            box-shadow: 0 5px 20px rgba(111, 66, 193, 0.3);
        }
        .logout-btn {
            background: linear-gradient(135deg, #dc3545 0%, #c82333 100%);
            color: white;
            border: none;
        }
        .logout-btn:hover {
            background: linear-gradient(135deg, #c82333 0%, #bd2130 100%);
            transform: translateY(-2px);
            box-shadow: 0 5px 20px rgba(220, 53, 69, 0.3);
        }
        .nav a.active {
            background: #007bff;
            color: white;
            font-weight: bold;
        }
        .error { 
            color: #721c24; 
            padding: 20px; 
            background: #f8d7da; 
            border-radius: 10px; 
            margin-bottom: 25px; 
            border: 1px solid #f5c6cb;
            font-weight: 500;
            font-size: 16px;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .success { 
            color: #155724; 
            padding: 20px; 
            background: #d4edda; 
            border-radius: 10px; 
            margin-bottom: 25px; 
            border: 1px solid #c3e6cb;
            font-weight: 500;
            font-size: 16px;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .stats-section {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 30px;
            border-radius: 15px;
            margin-bottom: 40px;
            box-shadow: 0 10px 30px rgba(102, 126, 234, 0.3);
        }
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
            gap: 25px;
            margin-top: 25px;
        }
        .stat-card {
            background: rgba(255, 255, 255, 0.15);
            padding: 25px;
            border-radius: 12px;
            text-align: center;
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.2);
            transition: transform 0.3s;
        }
        .stat-card:hover {
            transform: translateY(-5px);
            background: rgba(255, 255, 255, 0.25);
        }
        .stat-number {
            font-size: 3em;
            font-weight: bold;
            margin: 15px 0;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.2);
        }
        .form-section, .users-section { 
            background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
            padding: 30px; 
            border-radius: 15px; 
            margin-bottom: 40px; 
            border: 1px solid #dee2e6;
            box-shadow: 0 5px 20px rgba(0,0,0,0.05);
        }
        .form-group { 
            margin-bottom: 25px; 
        }
        label { 
            display: block; 
            margin-bottom: 10px; 
            font-weight: bold;
            color: #495057;
            font-size: 16px;
        }
        input, select { 
            width: 100%; 
            max-width: 400px; 
            padding: 14px; 
            box-sizing: border-box; 
            border: 2px solid #ced4da;
            border-radius: 10px;
            font-size: 16px;
            transition: all 0.3s;
        }
        input:focus, select:focus {
            outline: none;
            border-color: #007bff;
            box-shadow: 0 0 0 3px rgba(0,123,255,0.15);
            transform: translateY(-2px);
        }
        button[type="submit"] { 
            background: linear-gradient(135deg, #007bff 0%, #0056b3 100%); 
            color: white; 
            padding: 16px 35px; 
            border: none; 
            cursor: pointer; 
            border-radius: 10px;
            font-size: 16px;
            font-weight: bold;
            transition: all 0.3s;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        button[type="submit"]:hover { 
            background: linear-gradient(135deg, #0056b3 0%, #004494 100%);
            transform: translateY(-3px);
            box-shadow: 0 8px 25px rgba(0,123,255,0.3);
        }
        table { 
            width: 100%; 
            border-collapse: separate; 
            border-spacing: 0;
            margin-top: 25px; 
            background: white;
            box-shadow: 0 5px 20px rgba(0,0,0,0.08);
            border-radius: 12px;
            overflow: hidden;
        }
        th, td { 
            padding: 18px; 
            text-align: left; 
            border-bottom: 1px solid #e9ecef; 
        }
        th { 
            background: linear-gradient(135deg, #007bff 0%, #0056b3 100%); 
            color: white; 
            font-weight: 600;
            font-size: 15px;
        }
        tr:hover { 
            background-color: #f8f9fa; 
        }
        tr:last-child td {
            border-bottom: none;
        }
        .actions { 
            white-space: nowrap;
        }
        .actions a { 
            margin-right: 10px; 
            text-decoration: none; 
            padding: 8px 15px;
            border-radius: 6px;
            font-size: 14px;
            display: inline-flex;
            align-items: center;
            gap: 6px;
            transition: all 0.3s;
        }
        .edit-btn { 
            color: #007bff; 
            background: #e7f1ff;
            border: 1px solid #b3d7ff;
        }
        .edit-btn:hover {
            background: #d0e7ff;
            transform: translateY(-2px);
        }
        .delete-btn { 
            color: #dc3545; 
            background: #f8d7da;
            border: 1px solid #f1b0b7;
        }
        .delete-btn:hover {
            background: #f5c2c7;
            transform: translateY(-2px);
        }
        .role-form {
            display: inline-block;
            margin-left: 15px;
        }
        .role-select {
            width: auto;
            padding: 8px;
            font-size: 14px;
            border-radius: 6px;
            border: 2px solid #ced4da;
        }
        .role-submit {
            padding: 8px 15px;
            font-size: 14px;
            margin-left: 8px;
            background: #6c757d;
            color: white;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            transition: all 0.3s;
        }
        .role-submit:hover {
            background: #5a6268;
            transform: translateY(-2px);
        }
        .badge {
            display: inline-block;
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 13px;
            font-weight: bold;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        .badge-admin {
            background: linear-gradient(135deg, #dc3545 0%, #c82333 100%);
            color: white;
        }
        .badge-user {
            background: linear-gradient(135deg, #28a745 0%, #20c997 100%);
            color: white;
        }
        .badge-unknown {
            background: linear-gradient(135deg, #6c757d 0%, #545b62 100%);
            color: white;
        }
        h1 {
            color: #343a40;
            margin-bottom: 15px;
            font-size: 2.5em;
            display: flex;
            align-items: center;
            gap: 15px;
        }
        h2 {
            color: #495057;
            margin-bottom: 25px;
            font-size: 1.8em;
            display: flex;
            align-items: center;
            gap: 12px;
        }
        .info-section {
            margin-top: 40px; 
            padding: 30px; 
            background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
            border-radius: 15px; 
            font-size: 15px; 
            color: #495057;
            border: 1px solid #dee2e6;
        }
        .info-section h3 {
            color: #495057;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .info-section ul {
            padding-left: 20px;
            line-height: 1.8;
        }
        .info-section li {
            margin-bottom: 8px;
        }
        .admin-welcome {
            background: linear-gradient(135deg, #fff3cd 0%, #ffeaa7 100%);
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 30px;
            border-left: 5px solid #ffc107;
            font-size: 16px;
        }
        @media (max-width: 768px) {
            .container {
                padding: 15px;
            }
            .nav {
                flex-direction: column;
                align-items: stretch;
            }
            .nav a {
                justify-content: center;
            }
            .site-btn {
                margin-left: 0;
                margin-top: 10px;
            }
            table {
                display: block;
                overflow-x: auto;
            }
            .stats-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <div class="container">
        <!-- Навигация -->
        <div class="nav">
            <a href="index.php"><i class="fas fa-home"></i> Главная</a>
            <a href="profile.php"><i class="fas fa-user"></i> Мой профиль</a>
            <a href="admin.php" class="admin-btn active"><i class="fas fa-crown"></i> Админ-панель</a>
            <!-- Кнопка "На сайт" - переносит на services.php -->
            <a href="services.php" class="site-btn">
                <i class="fas fa-external-link-alt"></i> На сайт
            </a>
            <a href="logout.php" class="logout-btn">
                <i class="fas fa-sign-out-alt"></i> Выйти
            </a>
        </div>
        
        <!-- Приветствие администратора -->
        <div class="admin-welcome">
            <h1><i class="fas fa-crown"></i> Панель администратора</h1>
            <p>Добро пожаловать, <strong><?php echo htmlspecialchars($_SESSION['login'] ?? 'Администратор'); ?></strong>! Вы вошли как администратор системы.</p>
        </div>
        
        <!-- Сообщения об ошибках/успехе -->
        <?php if ($error): ?>
            <div class="error">
                <i class="fas fa-exclamation-circle"></i> <?php echo htmlspecialchars($error); ?>
            </div>
        <?php endif; ?>
        
        <?php if ($success): ?>
            <div class="success">
                <i class="fas fa-check-circle"></i> <?php echo htmlspecialchars($success); ?>
            </div>
        <?php endif; ?>
        
        <!-- Статистика -->
        <div class="stats-section">
            <h2 style="margin-top: 0; color: white;"><i class="fas fa-chart-bar"></i> Статистика системы</h2>
            <div class="stats-grid">
                <div class="stat-card">
                    <div><i class="fas fa-users"></i> Всего пользователей</div>
                    <div class="stat-number"><?php echo $stats['total'] ?? 0; ?></div>
                </div>
                <div class="stat-card">
                    <div><i class="fas fa-crown"></i> Администраторы</div>
                    <div class="stat-number"><?php echo $stats['admins'] ?? 0; ?></div>
                </div>
                <div class="stat-card">
                    <div><i class="fas fa-user"></i> Обычные пользователи</div>
                    <div class="stat-number"><?php echo $stats['users'] ?? 0; ?></div>
                </div>
                <div class="stat-card">
                    <div><i class="fas fa-calendar-day"></i> Зарегистрировано сегодня</div>
                    <div class="stat-number"><?php echo $stats['today'] ?? 0; ?></div>
                </div>
            </div>
        </div>
        
        <!-- Форма добавления пользователя -->
        <div class="form-section">
            <h2><i class="fas fa-user-plus"></i> Добавить нового пользователя</h2>
            <form method="POST" action="">
                <div class="form-group">
                    <label><i class="fas fa-user-tag"></i> Логин:</label>
                    <input type="text" name="login" required minlength="3" maxlength="50" placeholder="Введите логин пользователя">
                </div>
                
                <div class="form-group">
                    <label><i class="fas fa-envelope"></i> Email:</label>
                    <input type="email" name="email" required placeholder="email@example.com">
                </div>
                
                <div class="form-group">
                    <label><i class="fas fa-lock"></i> Пароль:</label>
                    <input type="password" name="password" required minlength="6" placeholder="Минимум 6 символов">
                </div>
                
                <div class="form-group">
                    <label><i class="fas fa-user-shield"></i> Роль:</label>
                    <select name="role">
                        <option value="user"><i class="fas fa-user"></i> Обычный пользователь</option>
                        <option value="admin"><i class="fas fa-crown"></i> Администратор</option>
                    </select>
                </div>
                
                <button type="submit" name="add_user">
                    <i class="fas fa-plus-circle"></i> Добавить пользователя
                </button>
            </form>
        </div>
        
        <!-- Список пользователей -->
        <div class="users-section">
            <h2><i class="fas fa-users-cog"></i> Список пользователей (<?php echo count($users); ?>)</h2>
            
            <table>
                <thead>
                    <tr>
                        <th><i class="fas fa-id-card"></i> ID</th>
                        <th><i class="fas fa-user"></i> Логин</th>
                        <th><i class="fas fa-envelope"></i> Email</th>
                        <th><i class="fas fa-user-tag"></i> Роль</th>
                        <?php if ($has_created_at): ?>
                        <th><i class="fas fa-calendar-alt"></i> Дата регистрации</th>
                        <?php endif; ?>
                        <th><i class="fas fa-cogs"></i> Действия</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($users)): ?>
                    <tr>
                        <td colspan="<?php echo $has_created_at ? 6 : 5; ?>" style="text-align: center; padding: 40px;">
                            <i class="fas fa-user-slash" style="font-size: 48px; color: #ccc; margin-bottom: 15px; display: block;"></i>
                            <p style="color: #999; font-size: 18px;">Нет пользователей в системе</p>
                        </td>
                    </tr>
                    <?php else: ?>
                    <?php foreach ($users as $user): ?>
                    <tr>
                        <td><?php echo $user['id']; ?></td>
                        <td>
                            <strong><?php echo htmlspecialchars($user['login']); ?></strong>
                            <?php if ($user['id'] == $_SESSION['user_id']): ?>
                            <span style="color: #007bff; font-size: 0.9em; display: block; margin-top: 5px;">
                                <i class="fas fa-user-check"></i> (Это вы)
                            </span>
                            <?php endif; ?>
                        </td>
                        <td><?php echo htmlspecialchars($user['email']); ?></td>
                        <td>
                            <?php 
                            $role = $user['role'] ?? 'user';
                            $badge_class = $role === 'admin' ? 'badge-admin' : 'badge-user';
                            $role_text = $role === 'admin' ? 'Администратор' : 'Пользователь';
                            ?>
                            <span class="badge <?php echo $badge_class; ?>"><?php echo $role_text; ?></span>
                            
                            <!-- Форма изменения роли (только для других пользователей) -->
                            <?php if ($user['id'] != $_SESSION['user_id'] && $has_role): ?>
                            <form method="POST" action="" class="role-form" onsubmit="return confirm('Изменить роль пользователя <?php echo htmlspecialchars($user['login']); ?>?')">
                                <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                                <select name="new_role" class="role-select">
                                    <option value="user" <?php echo $role === 'user' ? 'selected' : ''; ?>><i class="fas fa-user"></i> Пользователь</option>
                                    <option value="admin" <?php echo $role === 'admin' ? 'selected' : ''; ?>><i class="fas fa-crown"></i> Администратор</option>
                                </select>
                                <button type="submit" name="change_role" class="role-submit">
                                    <i class="fas fa-sync-alt"></i> Изменить
                                </button>
                            </form>
                            <?php endif; ?>
                        </td>
                        
                        <?php if ($has_created_at): ?>
                        <td>
                            <?php 
                            if (!empty($user['created_at'])) {
                                echo '<i class="far fa-calendar"></i> ' . date('d.m.Y H:i', strtotime($user['created_at']));
                            } else {
                                echo 'Не указана';
                            }
                            ?>
                        </td>
                        <?php endif; ?>
                        
                        <td class="actions">
                            <a href="edit_user.php?id=<?php echo $user['id']; ?>" class="edit-btn">
                                <i class="fas fa-edit"></i> Редактировать
                            </a>
                            
                            <?php if ($user['id'] != $_SESSION['user_id']): ?>
                            <a href="?delete=<?php echo $user['id']; ?>" class="delete-btn" 
                               onclick="return confirm('Вы уверены, что хотите удалить пользователя <?php echo htmlspecialchars($user['login']); ?>?\n\nЭто действие нельзя отменить!')">
                               <i class="fas fa-trash-alt"></i> Удалить
                            </a>
                            <?php else: ?>
                            <span style="color: #999; font-size: 0.9em; padding: 8px 15px; background: #f8f9fa; border-radius: 6px;">
                                <i class="fas fa-ban"></i> Удаление недоступно
                            </span>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        
        <!-- Информация о системе -->
        <div class="info-section">
            <h3><i class="fas fa-info-circle"></i> Информация о системе</h3>
            <p><strong><i class="fas fa-user"></i> Текущий пользователь:</strong> <?php echo htmlspecialchars($_SESSION['login'] ?? 'Неизвестно'); ?> (ID: <?php echo $_SESSION['user_id'] ?? 'Неизвестно'; ?>)</p>
            <p><strong><i class="fas fa-user-shield"></i> Ваша роль:</strong> <span class="badge badge-admin">Администратор</span></p>
            <p><strong><i class="fas fa-unlock-alt"></i> Права администратора:</strong></p>
            <ul>
                <li><i class="fas fa-eye"></i> Просмотр всех пользователей</li>
                <li><i class="fas fa-user-plus"></i> Добавление новых пользователей</li>
                <li><i class="fas fa-user-tag"></i> Изменение ролей пользователей</li>
                <li><i class="fas fa-user-times"></i> Удаление пользователей (кроме себя)</li>
                <li><i class="fas fa-edit"></i> Редактирование данных пользователей</li>
                <li><i class="fas fa-chart-bar"></i> Просмотр статистики системы</li>
            </ul>
            <p style="margin-top: 20px; padding: 15px; background: #e7f3ff; border-radius: 8px; border-left: 4px solid #007bff;">
                <i class="fas fa-lightbulb"></i> <strong>Совет:</strong> Используйте кнопку <strong>"На сайт"</strong> для перехода на страницу услуг кинотеатра и проверки работы пользовательской части системы.
            </p>
        </div>
    </div>
    
    <script>
        // Автоматическое скрытие сообщений через 5 секунд
        setTimeout(function() {
            var messages = document.querySelectorAll('.error, .success');
            messages.forEach(function(msg) {
                msg.style.opacity = '0';
                msg.style.transition = 'opacity 0.5s';
                setTimeout(function() {
                    msg.style.display = 'none';
                }, 500);
            });
        }, 5000);
        
        // Показать/скрыть пароль в форме добавления пользователя
        const passwordInput = document.querySelector('input[name="password"]');
        if (passwordInput) {
            const wrapper = document.createElement('div');
            wrapper.style.position = 'relative';
            passwordInput.parentNode.insertBefore(wrapper, passwordInput);
            wrapper.appendChild(passwordInput);
            
            const toggleBtn = document.createElement('button');
            toggleBtn.innerHTML = '👁️';
            toggleBtn.type = 'button';
            toggleBtn.style.position = 'absolute';
            toggleBtn.style.right = '15px';
            toggleBtn.style.top = '50%';
            toggleBtn.style.transform = 'translateY(-50%)';
            toggleBtn.style.background = 'none';
            toggleBtn.style.border = 'none';
            toggleBtn.style.cursor = 'pointer';
            toggleBtn.style.fontSize = '18px';
            toggleBtn.style.padding = '5px';
            
            toggleBtn.addEventListener('click', function() {
                if (passwordInput.type === 'password') {
                    passwordInput.type = 'text';
                    this.innerHTML = '🔒';
                } else {
                    passwordInput.type = 'password';
                    this.innerHTML = '👁️';
                }
            });
            
            wrapper.appendChild(toggleBtn);
        }
        
        // Подтверждение перед удалением
        function confirmDelete(userName) {
            return confirm('Вы уверены, что хотите удалить пользователя "' + userName + '"?\n\nЭто действие нельзя отменить!');
        }
        
        // Анимация при загрузке
        document.addEventListener('DOMContentLoaded', function() {
            const cards = document.querySelectorAll('.stat-card, .form-section, .users-section, .info-section');
            cards.forEach((card, index) => {
                card.style.opacity = '0';
                card.style.transform = 'translateY(30px)';
                card.style.transition = 'opacity 0.8s, transform 0.8s';
                
                setTimeout(() => {
                    card.style.opacity = '1';
                    card.style.transform = 'translateY(0)';
                }, 150 * (index + 1));
            });
        });
        
        // Подсветка строк таблицы при наведении
        const tableRows = document.querySelectorAll('tbody tr');
        tableRows.forEach(row => {
            row.addEventListener('mouseenter', function() {
                this.style.transform = 'scale(1.01)';
                this.style.transition = 'transform 0.3s';
            });
            
            row.addEventListener('mouseleave', function() {
                this.style.transform = 'scale(1)';
            });
        });
    </script>
</body>
</html>