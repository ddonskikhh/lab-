<?php
// services.php - Страница услуг кинотеатра (доступна всем)
require_once 'config.php'; // Подключаем конфиг для сессий

// Обработка бронирования
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['book_service'])) {
    if (!isLoggedIn()) {
        $booking_error = 'Для бронирования необходимо войти в систему';
    } else {
        $service_name = $_POST['service_name'] ?? '';
        $service_price = $_POST['service_price'] ?? '';
        $booking_date = $_POST['booking_date'] ?? '';
        $booking_time = $_POST['booking_time'] ?? '';
        $guests_count = $_POST['guests_count'] ?? 1;
        
        // Простая валидация
        if (empty($service_name) || empty($booking_date) || empty($booking_time)) {
            $booking_error = 'Пожалуйста, заполните все обязательные поля';
        } else {
            $booking_success = true;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Услуги кинотеатра CINEMAX</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Arial', sans-serif;
        }
        
        body {
            background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
            color: #fff;
            min-height: 100vh;
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }
        
        /* Навигация */
        .navbar {
            background: rgba(0, 0, 0, 0.8);
            padding: 15px 0;
            position: sticky;
            top: 0;
            z-index: 1000;
            backdrop-filter: blur(10px);
        }
        
        .nav-container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .logo {
            font-size: 24px;
            font-weight: bold;
            color: #ffd700;
            text-decoration: none;
        }
        
        .nav-links {
            display: flex;
            gap: 30px;
            align-items: center;
        }
        
        .nav-links a {
            color: #fff;
            text-decoration: none;
            font-size: 16px;
            transition: color 0.3s;
            position: relative;
        }
        
        .nav-links a:hover {
            color: #ffd700;
        }
        
        .nav-links a.active {
            color: #ffd700;
        }
        
        .nav-links a.active::after {
            content: '';
            position: absolute;
            bottom: -5px;
            left: 0;
            width: 100%;
            height: 2px;
            background: #ffd700;
        }
        
        /* Заголовок */
        .header {
            text-align: center;
            padding: 60px 0 40px;
            background: linear-gradient(rgba(0,0,0,0.7), rgba(0,0,0,0.7)), 
                        url('https://images.unsplash.com/photo-1489599809516-9827b6d1cf13?auto=format&fit=crop&w=1200&q=80');
            background-size: cover;
            background-position: center;
            margin-bottom: 40px;
            border-radius: 15px;
        }
        
        .header h1 {
            font-size: 48px;
            margin-bottom: 15px;
            color: #ffd700;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.5);
        }
        
        .header p {
            font-size: 18px;
            max-width: 800px;
            margin: 0 auto;
            line-height: 1.6;
            opacity: 0.9;
        }
        
        /* Карточки услуг */
        .services-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
            gap: 30px;
            margin-bottom: 60px;
        }
        
        .service-card {
            background: rgba(255, 255, 255, 0.05);
            border-radius: 15px;
            overflow: hidden;
            transition: transform 0.3s, box-shadow 0.3s;
            border: 1px solid rgba(255, 215, 0, 0.1);
        }
        
        .service-card:hover {
            transform: translateY(-10px);
            box-shadow: 0 20px 40px rgba(255, 215, 0, 0.1);
            border-color: rgba(255, 215, 0, 0.3);
        }
        
        .service-image {
            height: 200px;
            overflow: hidden;
        }
        
        .service-image img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            transition: transform 0.5s;
        }
        
        .service-card:hover .service-image img {
            transform: scale(1.1);
        }
        
        .service-content {
            padding: 25px;
        }
        
        .service-title {
            font-size: 22px;
            margin-bottom: 15px;
            color: #ffd700;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .service-icon {
            font-size: 24px;
        }
        
        .service-description {
            color: #ccc;
            line-height: 1.6;
            margin-bottom: 20px;
        }
        
        .service-features {
            list-style: none;
            margin-bottom: 25px;
        }
        
        .service-features li {
            padding: 8px 0;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
            color: #aaa;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .service-features li:last-child {
            border-bottom: none;
        }
        
        .feature-icon {
            color: #ffd700;
            font-size: 14px;
        }
        
        .service-price {
            font-size: 24px;
            color: #ffd700;
            font-weight: bold;
            text-align: right;
            margin-top: 20px;
        }
        
        /* Цены */
        .pricing-section {
            background: rgba(255, 215, 0, 0.05);
            padding: 50px;
            border-radius: 15px;
            margin-bottom: 60px;
            border: 1px solid rgba(255, 215, 0, 0.1);
        }
        
        .pricing-title {
            text-align: center;
            font-size: 36px;
            margin-bottom: 40px;
            color: #ffd700;
        }
        
        .pricing-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 30px;
        }
        
        .price-card {
            background: rgba(255, 255, 255, 0.05);
            padding: 30px;
            border-radius: 10px;
            text-align: center;
            transition: all 0.3s;
            border: 1px solid transparent;
        }
        
        .price-card:hover {
            background: rgba(255, 215, 0, 0.1);
            border-color: #ffd700;
        }
        
        .price-card.popular {
            transform: scale(1.05);
            border-color: #ffd700;
            position: relative;
        }
        
        .popular-badge {
            position: absolute;
            top: -12px;
            left: 50%;
            transform: translateX(-50%);
            background: #ffd700;
            color: #000;
            padding: 5px 20px;
            border-radius: 20px;
            font-weight: bold;
            font-size: 14px;
        }
        
        .price-type {
            font-size: 20px;
            margin-bottom: 20px;
            color: #ffd700;
        }
        
        .price-amount {
            font-size: 48px;
            font-weight: bold;
            color: #fff;
            margin-bottom: 10px;
        }
        
        .price-period {
            color: #aaa;
            margin-bottom: 30px;
        }
        
        /* Призыв к действию */
        .cta-section {
            text-align: center;
            padding: 60px;
            background: linear-gradient(135deg, #ffd700 0%, #ffed4e 100%);
            border-radius: 15px;
            margin-bottom: 60px;
        }
        
        .cta-section h2 {
            color: #000;
            font-size: 36px;
            margin-bottom: 20px;
        }
        
        .cta-section p {
            color: #333;
            font-size: 18px;
            margin-bottom: 30px;
            max-width: 600px;
            margin-left: auto;
            margin-right: auto;
        }
        
        .cta-button {
            display: inline-block;
            background: #000;
            color: #ffd700;
            padding: 15px 40px;
            border-radius: 50px;
            text-decoration: none;
            font-weight: bold;
            font-size: 18px;
            transition: all 0.3s;
            border: 2px solid transparent;
            cursor: pointer;
        }
        
        .cta-button:hover {
            background: transparent;
            border-color: #000;
            color: #000;
        }
        
        /* Модальное окно бронирования */
        .booking-modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.8);
            z-index: 2000;
            justify-content: center;
            align-items: center;
            backdrop-filter: blur(5px);
        }
        
        .modal-content {
            background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
            padding: 40px;
            border-radius: 20px;
            width: 90%;
            max-width: 500px;
            border: 2px solid #ffd700;
            box-shadow: 0 20px 50px rgba(255, 215, 0, 0.2);
            position: relative;
            animation: modalSlideIn 0.3s ease;
        }
        
        @keyframes modalSlideIn {
            from {
                opacity: 0;
                transform: translateY(-50px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        .modal-header {
            text-align: center;
            margin-bottom: 30px;
        }
        
        .modal-title {
            font-size: 28px;
            color: #ffd700;
            margin-bottom: 10px;
        }
        
        .modal-subtitle {
            color: #aaa;
            font-size: 14px;
        }
        
        .modal-close {
            position: absolute;
            top: 20px;
            right: 20px;
            background: none;
            border: none;
            color: #ffd700;
            font-size: 24px;
            cursor: pointer;
            transition: transform 0.3s;
        }
        
        .modal-close:hover {
            transform: rotate(90deg);
        }
        
        /* Форма бронирования */
        .booking-form {
            display: grid;
            gap: 20px;
        }
        
        .form-group {
            margin-bottom: 15px;
        }
        
        .form-label {
            display: block;
            margin-bottom: 8px;
            color: #ffd700;
            font-weight: 500;
        }
        
        .form-input, .form-select {
            width: 100%;
            padding: 12px 15px;
            background: rgba(255, 255, 255, 0.1);
            border: 1px solid rgba(255, 215, 0, 0.3);
            border-radius: 8px;
            color: #fff;
            font-size: 16px;
            transition: all 0.3s;
        }
        
        .form-input:focus, .form-select:focus {
            outline: none;
            border-color: #ffd700;
            box-shadow: 0 0 0 2px rgba(255, 215, 0, 0.1);
        }
        
        .form-input::placeholder {
            color: #777;
        }
        
        /* Стили для выпадающего списка */
        .form-select option {
            background: #1a1a2e;
            color: #fff;
            padding: 10px;
        }
        
        /* Для браузеров, которые поддерживают стилизацию option */
        .form-select optgroup {
            background: #1a1a2e;
            color: #ffd700;
            font-weight: bold;
        }
        
        /* Специальные стили для Webkit браузеров (Chrome, Safari) */
        .form-select::-webkit-scrollbar {
            width: 8px;
        }
        
        .form-select::-webkit-scrollbar-track {
            background: rgba(255, 255, 255, 0.1);
            border-radius: 4px;
        }
        
        .form-select::-webkit-scrollbar-thumb {
            background: #ffd700;
            border-radius: 4px;
        }
        
        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 15px;
        }
        
        .submit-booking-btn {
            width: 100%;
            padding: 15px;
            background: linear-gradient(135deg, #ffd700 0%, #ffed4e 100%);
            border: none;
            border-radius: 10px;
            color: #000;
            font-size: 16px;
            font-weight: bold;
            cursor: pointer;
            transition: all 0.3s;
            margin-top: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
        }
        
        .submit-booking-btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 10px 25px rgba(255, 215, 0, 0.4);
        }
        
        .submit-booking-btn:disabled {
            opacity: 0.5;
            cursor: not-allowed;
            transform: none;
            box-shadow: none;
        }
        
        /* Сообщения о бронировании */
        .booking-message {
            padding: 20px;
            border-radius: 10px;
            margin: 20px 0;
            text-align: center;
            animation: fadeIn 0.5s ease;
        }
        
        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        .booking-success {
            background: rgba(40, 167, 69, 0.1);
            border: 1px solid rgba(40, 167, 69, 0.3);
            color: #28a745;
        }
        
        .booking-error {
            background: rgba(220, 53, 69, 0.1);
            border: 1px solid rgba(220, 53, 69, 0.3);
            color: #dc3545;
        }
        
        .booking-info {
            margin-top: 15px;
            font-size: 14px;
            color: #aaa;
        }
        
        /* Футер */
        .footer {
            background: rgba(0, 0, 0, 0.9);
            padding: 40px 0;
            margin-top: 60px;
            border-top: 1px solid rgba(255, 215, 0, 0.1);
        }
        
        .footer-content {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 40px;
        }
        
        .footer-section h3 {
            color: #ffd700;
            margin-bottom: 20px;
            font-size: 20px;
        }
        
        .footer-links {
            list-style: none;
        }
        
        .footer-links li {
            margin-bottom: 10px;
        }
        
        .footer-links a {
            color: #ccc;
            text-decoration: none;
            transition: color 0.3s;
        }
        
        .footer-links a:hover {
            color: #ffd700;
        }
        
        .contact-info {
            color: #ccc;
            line-height: 1.6;
        }
        
        .copyright {
            text-align: center;
            padding-top: 30px;
            border-top: 1px solid rgba(255, 255, 255, 0.1);
            color: #666;
            font-size: 14px;
            margin-top: 30px;
        }
        
        /* Адаптивность */
        @media (max-width: 768px) {
            .header h1 {
                font-size: 36px;
            }
            
            .services-grid {
                grid-template-columns: 1fr;
            }
            
            .nav-container {
                flex-direction: column;
                gap: 15px;
            }
            
            .nav-links {
                flex-wrap: wrap;
                justify-content: center;
            }
            
            .form-row {
                grid-template-columns: 1fr;
            }
            
            .modal-content {
                padding: 20px;
                width: 95%;
            }
        }
    </style>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <!-- Навигация -->
    <nav class="navbar">
        <div class="nav-container">
            <a href="index.php" class="logo">CINEMAX</a>
            <div class="nav-links">
                <a href="index.php">Главная</a>
                <a href="services.php" class="active">Услуги</a>
                <?php if (isLoggedIn()): ?>
                    <?php if (isAdmin()): ?>
                        <a href="admin.php"><i class="fas fa-crown"></i> Админ</a>
                    <?php endif; ?>
                    <a href="profile.php"><i class="fas fa-user"></i> Профиль</a>
                    <a href="logout.php"><i class="fas fa-sign-out-alt"></i> Выйти</a>
                <?php else: ?>
                    <a href="login.php"><i class="fas fa-sign-in-alt"></i> Войти</a>
                    <a href="register.php"><i class="fas fa-user-plus"></i> Регистрация</a>
                <?php endif; ?>
            </div>
        </div>
    </nav>

    <div class="container">
        <!-- Заголовок -->
        <header class="header">
            <h1><i class="fas fa-film"></i> Услуги кинотеатра CINEMAX</h1>
            <p>Откройте для себя мир кинематографа с нашими премиальными услугами. Современные технологии, комфортные залы и непревзойденная атмосфера ждут вас!</p>
        </header>

        <!-- Список услуг -->
        <div class="services-grid">
            <!-- Услуга 1 -->
            <div class="service-card">
                <div class="service-image">
                    <img src="img/kinozal (1).jpg" alt="Кинозалы">
                </div>
                <div class="service-content">
                    <h3 class="service-title">
                        <i class="fas fa-theater-masks service-icon"></i>
                        Кинозалы премиум-класса
                    </h3>
                    <p class="service-description">
                        Современные кинозалы с комфортными креслами, идеальной акустикой и системой вентиляции. 
                        Погрузитесь в атмосферу фильма с нашими технологиями Dolby Atmos и IMAX.
                    </p>
                    <ul class="service-features">
                        <li><i class="fas fa-check feature-icon"></i> Кресла с подогревом и массажем</li>
                        <li><i class="fas fa-check feature-icon"></i> Система Dolby Atmos 7.1</li>
                        <li><i class="fas fa-check feature-icon"></i> Экран 4K Ultra HD</li>
                        <li><i class="fas fa-check feature-icon"></i> Климат-контроль</li>
                    </ul>
                    <div class="service-price">от 350 ₽</div>
                </div>
            </div>

            <!-- Услуга 2 -->
            <div class="service-card">
                <div class="service-image">
                    <img src="img/edaa.avif" alt="Еда и напитки">
                </div>
                <div class="service-content">
                    <h3 class="service-title">
                        <i class="fas fa-utensils service-icon"></i>
                        Еда и напитки
                    </h3>
                    <p class="service-description">
                        Широкий выбор свежих закусок, попкорна различных вкусов и освежающих напитков. 
                        Также доступно меню ресторана с доставкой прямо в кинозал.
                    </p>
                    <ul class="service-features">
                        <li><i class="fas fa-check feature-icon"></i> Попкорн 5 видов</li>
                        <li><i class="fas fa-check feature-icon"></i> Напитки из сироп-бара</li>
                        <li><i class="fas fa-check feature-icon"></i> Горячие закуски</li>
                        <li><i class="fas fa-check feature-icon"></i> Доставка в зал</li>
                    </ul>
                    <div class="service-price">от 150 ₽</div>
                </div>
            </div>

            <!-- Услуга 3 -->
            <div class="service-card">
                <div class="service-image">
                    <img src="img/guest.png" alt="VIP зона">
                </div>
                <div class="service-content">
                    <h3 class="service-title">
                        <i class="fas fa-crown service-icon"></i>
                        VIP обслуживание
                    </h3>
                    <p class="service-description">
                        Эксклюзивные услуги для самых требовательных гостей. 
                        Отдельные залы, личный консьерж и максимальный комфорт на протяжении всего посещения.
                    </p>
                    <ul class="service-features">
                        <li><i class="fas fa-check feature-icon"></i> Отдельный VIP зал</li>
                        <li><i class="fas fa-check feature-icon"></i> Личный консьерж</li>
                        <li><i class="fas fa-check feature-icon"></i> Премиум меню</li>
                        <li><i class="fas fa-check feature-icon"></i> Парковка у входа</li>
                    </ul>
                    <div class="service-price">от 1500 ₽</div>
                </div>
            </div>

            <!-- Услуга 4 -->
            <div class="service-card">
                <div class="service-image">
                    <img src="img/лщыьшл.jpg" alt="Детская зона">
                </div>
                <div class="service-content">
                    <h3 class="service-title">
                        <i class="fas fa-child service-icon"></i>
                        Детская зона
                    </h3>
                    <p class="service-description">
                        Безопасное и увлекательное пространство для детей. 
                        Аниматоры, развивающие игры и специальные детские сеансы под присмотром профессионалов.
                    </p>
                    <ul class="service-features">
                        <li><i class="fas fa-check feature-icon"></i> Детские сеансы</li>
                        <li><i class="fas fa-check feature-icon"></i> Комната аниматоров</li>
                        <li><i class="fas fa-check feature-icon"></i> Безопасная мебель</li>
                        <li><i class="fas fa-check feature-icon"></i> Специальное меню</li>
                    </ul>
                    <div class="service-price">от 250 ₽</div>
                </div>
            </div>

            <!-- Услуга 5 -->
            <div class="service-card">
                <div class="service-image">
                    <img src="img/3d.jpg" alt="3D кино">
                </div>
                <div class="service-content">
                    <h3 class="service-title">
                        <i class="fas fa-vr-cardboard service-icon"></i>
                        3D и IMAX
                    </h3>
                    <p class="service-description">
                        Погрузитесь в мир трехмерного кино с нашими технологиями RealD 3D и IMAX. 
                        Очки последнего поколения и специально оборудованные залы для максимального эффекта.
                    </p>
                    <ul class="service-features">
                        <li><i class="fas fa-check feature-icon"></i> Технология RealD 3D</li>
                        <li><i class="fas fa-check feature-icon"></i> IMAX с лазерной проекцией</li>
                        <li><i class="fas fa-check feature-icon"></i> Беспроводные 3D очки</li>
                        <li><i class="fas fa-check feature-icon"></i> Специальные сеансы</li>
                    </ul>
                    <div class="service-price">от 500 ₽</div>
                </div>
            </div>

            <!-- Услуга 6 -->
            <div class="service-card">
                <div class="service-image">
                    <img src="img/adddd.webp" alt="Абонементы">
                </div>
                <div class="service-content">
                    <h3 class="service-title">
                        <i class="fas fa-ticket-alt service-icon"></i>
                        Кинокарты и абонементы
                    </h3>
                    <p class="service-description">
                        Выгодные предложения для постоянных посетителей. 
                        Скидки, бонусы и привилегии с нашими кинокартами различных категорий.
                    </p>
                    <ul class="service-features">
                        <li><i class="fas fa-check feature-icon"></i> Накопительные скидки</li>
                        <li><i class="fas fa-check feature-icon"></i> Приоритетная бронь</li>
                        <li><i class="fas fa-check feature-icon"></i> Бесплатные обновления</li>
                        <li><i class="fas fa-check feature-icon"></i> Подарочные сертификаты</li>
                    </ul>
                    <div class="service-price">от 2000 ₽/мес</div>
                </div>
            </div>
        </div>

        <!-- Таблица цен -->
        <section class="pricing-section">
            <h2 class="pricing-title"><i class="fas fa-tags"></i> Тарифы на посещение</h2>
            <div class="pricing-grid">
                <div class="price-card">
                    <div class="price-type">Базовый</div>
                    <div class="price-amount">350 ₽</div>
                    <div class="price-period">за сеанс</div>
                    <ul class="service-features">
                        <li>Стандартный зал</li>
                        <li>Одно место</li>
                        <li>2D формат</li>
                        <li>Базовые закуски</li>
                    </ul>
                </div>
                
                <div class="price-card popular">
                    <div class="popular-badge">ПОПУЛЯРНЫЙ</div>
                    <div class="price-type">Комфорт</div>
                    <div class="price-amount">650 ₽</div>
                    <div class="price-period">за сеанс</div>
                    <ul class="service-features">
                        <li>Премиум зал</li>
                        <li>Удобные кресла</li>
                        <li>3D/IMAX на выбор</li>
                        <li>Набор закусок</li>
                    </ul>
                </div>
                
                <div class="price-card">
                    <div class="price-type">VIP</div>
                    <div class="price-amount">1500 ₽</div>
                    <div class="price-period">за сеанс</div>
                    <ul class="service-features">
                        <li>VIP зал</li>
                        <li>Массажные кресла</li>
                        <li>Любой формат</li>
                        <li>Ресторанное меню</li>
                    </ul>
                </div>
            </div>
        </section>

        <!-- Призыв к действию -->
        <section class="cta-section">
            <h2>Готовы окунуться в мир кино?</h2>
            <p>Зарегистрируйтесь сейчас и получите скидку 20% на первый визит! Также вы сможете бронировать билеты онлайн и получать специальные предложения.</p>
            <?php if (isLoggedIn()): ?>
                <button class="cta-button" id="openBookingModal">Забронировать билеты</button>
            <?php else: ?>
                <a href="register.php" class="cta-button">Зарегистрироваться</a>
            <?php endif; ?>
        </section>
    </div>

    <!-- Модальное окно бронирования -->
    <div class="booking-modal" id="bookingModal">
        <div class="modal-content">
            <button class="modal-close" id="closeBookingModal">&times;</button>
            
            <div class="modal-header">
                <h3 class="modal-title"><i class="fas fa-ticket-alt"></i> Бронирование услуги</h3>
                <p class="modal-subtitle">Заполните форму для бронирования</p>
            </div>

            <?php if (isset($booking_error)): ?>
                <div class="booking-message booking-error">
                    <i class="fas fa-exclamation-circle"></i>
                    <?php echo htmlspecialchars($booking_error); ?>
                </div>
            <?php endif; ?>

            <?php if (isset($booking_success) && $booking_success): ?>
                <div class="booking-message booking-success">
                    <i class="fas fa-check-circle"></i>
                    <h4>Бронирование успешно!</h4>
                    <p>Уважаемый <strong><?php echo htmlspecialchars($_SESSION['login'] ?? 'Пользователь'); ?></strong>, ваша услуга "<strong><?php echo htmlspecialchars($service_name); ?></strong>" успешно забронирована!</p>
                    <p>Стоимость: <strong><?php echo htmlspecialchars($service_price); ?></strong></p>
                    <p>Дата и время: <strong><?php echo htmlspecialchars($booking_date); ?> в <?php echo htmlspecialchars($booking_time); ?></strong></p>
                    <p>Количество гостей: <strong><?php echo htmlspecialchars($guests_count); ?></strong></p>
                    <div class="booking-info">
                        <p><i class="fas fa-info-circle"></i> Информация о бронировании отправлена на ваш email.</p>
                    </div>
                </div>
            <?php else: ?>
                <form method="POST" action="" class="booking-form" id="bookingForm">
                    <input type="hidden" name="book_service" value="1">
                    
                    <div class="form-group">
                        <label class="form-label">Выберите услугу *</label>
                        <select name="service_name" class="form-select" required style="color: #fff; background-color: #1a1a2e;">
                            <option value="" style="color: #777; background-color: #1a1a2e;">Выберите услугу...</option>
                            <option value="Кинозалы премиум-класса" style="color: #fff; background-color: #1a1a2e;">Кинозалы премиум-класса (от 350 ₽)</option>
                            <option value="Пакет Еда и напитки" style="color: #fff; background-color: #1a1a2e;">Пакет Еда и напитки (от 150 ₽)</option>
                            <option value="VIP обслуживание" style="color: #fff; background-color: #1a1a2e;">VIP обслуживание (от 1500 ₽)</option>
                            <option value="Детская зона" style="color: #fff; background-color: #1a1a2e;">Детская зона (от 250 ₽)</option>
                            <option value="3D и IMAX сеанс" style="color: #fff; background-color: #1a1a2e;">3D и IMAX сеанс (от 500 ₽)</option>
                            <option value="Кинокарта на месяц" style="color: #fff; background-color: #1a1a2e;">Кинокарта на месяц (от 2000 ₽)</option>
                            <option value="Семейный пакет" style="color: #fff; background-color: #1a1a2e;">Семейный пакет (от 1000 ₽)</option>
                            <option value="Романтический вечер" style="color: #fff; background-color: #1a1a2e;">Романтический вечер (от 2000 ₽)</option>
                            <option value="Корпоративный пакет" style="color: #fff; background-color: #1a1a2e;">Корпоративный пакет (от 5000 ₽)</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label class="form-label">Стоимость услуги *</label>
                        <select name="service_price" class="form-select" required style="color: #fff; background-color: #1a1a2e;">
                            <option value="" style="color: #777; background-color: #1a1a2e;">Выберите стоимость...</option>
                            <option value="350 ₽" style="color: #fff; background-color: #1a1a2e;">350 ₽ - Базовый сеанс</option>
                            <option value="650 ₽" style="color: #fff; background-color: #1a1a2e;">650 ₽ - Комфорт сеанс</option>
                            <option value="1500 ₽" style="color: #fff; background-color: #1a1a2e;">1500 ₽ - VIP сеанс</option>
                            <option value="150 ₽" style="color: #fff; background-color: #1a1a2e;">150 ₽ - Пакет закусок</option>
                            <option value="250 ₽" style="color: #fff; background-color: #1a1a2e;">250 ₽ - Детский пакет</option>
                            <option value="500 ₽" style="color: #fff; background-color: #1a1a2e;">500 ₽ - 3D сеанс</option>
                            <option value="1000 ₽" style="color: #fff; background-color: #1a1a2e;">1000 ₽ - Семейный пакет</option>
                            <option value="2000 ₽" style="color: #fff; background-color: #1a1a2e;">2000 ₽ - Премиум пакет</option>
                            <option value="5000 ₽" style="color: #fff; background-color: #1a1a2e;">5000 ₽ - Корпоративный пакет</option>
                        </select>
                    </div>

                    <div class="form-row">
                        <div class="form-group">
                            <label class="form-label">Дата посещения *</label>
                            <input type="date" name="booking_date" class="form-input" required min="<?php echo date('Y-m-d'); ?>">
                        </div>

                        <div class="form-group">
                            <label class="form-label">Время *</label>
                            <select name="booking_time" class="form-select" required style="color: #fff; background-color: #1a1a2e;">
                                <option value="" style="color: #777; background-color: #1a1a2e;">Выберите время...</option>
                                <option value="10:00" style="color: #fff; background-color: #1a1a2e;">10:00 - Утренний сеанс</option>
                                <option value="13:00" style="color: #fff; background-color: #1a1a2e;">13:00 - Дневной сеанс</option>
                                <option value="16:00" style="color: #fff; background-color: #1a1a2e;">16:00 - Вечерний сеанс</option>
                                <option value="19:00" style="color: #fff; background-color: #1a1a2e;">19:00 - Основной сеанс</option>
                                <option value="22:00" style="color: #fff; background-color: #1a1a2e;">22:00 - Ночной сеанс</option>
                                <option value="00:00" style="color: #fff; background-color: #1a1a2e;">00:00 - Полуночный сеанс</option>
                            </select>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="form-label">Количество гостей</label>
                        <select name="guests_count" class="form-select" style="color: #fff; background-color: #1a1a2e;">
                            <option value="1" style="color: #fff; background-color: #1a1a2e;">1 гость</option>
                            <option value="2" style="color: #fff; background-color: #1a1a2e;">2 гостя</option>
                            <option value="3" style="color: #fff; background-color: #1a1a2e;">3 гостя</option>
                            <option value="4" style="color: #fff; background-color: #1a1a2e;">4 гостя</option>
                            <option value="5" style="color: #fff; background-color: #1a1a2e;">5 гостей</option>
                            <option value="6" style="color: #fff; background-color: #1a1a2e;">6 гостей</option>
                            <option value="7" style="color: #fff; background-color: #1a1a2e;">7 гостей</option>
                            <option value="8" style="color: #fff; background-color: #1a1a2e;">8 гостей</option>
                            <option value="9" style="color: #fff; background-color: #1a1a2e;">9 гостей</option>
                            <option value="10" style="color: #fff; background-color: #1a1a2e;">10 гостей</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label class="form-label">Дополнительные пожелания</label>
                        <textarea name="special_requests" class="form-input" rows="3" placeholder="Укажите дополнительные пожелания..."></textarea>
                    </div>

                    <button type="submit" class="submit-booking-btn">
                        <i class="fas fa-check-circle"></i>
                        Подтвердить бронирование
                    </button>
                </form>
            <?php endif; ?>
        </div>
    </div>

    <!-- Футер -->
    <footer class="footer">
        <div class="footer-content">
            <div class="footer-section">
                <h3>О кинотеатре</h3>
                <p class="contact-info">
                    CINEMAX - современный кинотеатр с передовыми технологиями и непревзойденным сервисом.
                </p>
            </div>
            
            <div class="footer-section">
                <h3>Контакты</h3>
                <p class="contact-info">
                    <i class="fas fa-map-marker-alt"></i> г. Москва, ул. Кинотеатральная, 15<br>
                    <i class="fas fa-phone"></i> +7 (495) 123-45-67<br>
                    <i class="fas fa-envelope"></i> info@cinemax.ru
                </p>
            </div>
            
            <div class="footer-section">
                <h3>Быстрые ссылки</h3>
                <ul class="footer-links">
                    <li><a href="index.php">Главная</a></li>
                    <li><a href="services.php" class="active">Услуги</a></li>
                </ul>
            </div>
            
            <div class="footer-section">
                <h3>Часы работы</h3>
                <p class="contact-info">
                    Пн-Пт: 10:00 - 02:00<br>
                    Сб-Вс: 09:00 - 03:00<br>
                    Без перерывов и выходных
                </p>
            </div>
        </div>
        
        <div class="copyright">
            <p>&copy; 2024 Кинотеатр CINEMAX. Все права защищены.</p>
        </div>
    </footer>

    <script>
        // Плавная прокрутка
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function(e) {
                e.preventDefault();
                const target = document.querySelector(this.getAttribute('href'));
                if (target) {
                    target.scrollIntoView({
                        behavior: 'smooth',
                        block: 'start'
                    });
                }
            });
        });

        // Анимация появления карточек
        const observerOptions = {
            threshold: 0.1,
            rootMargin: '0px 0px -50px 0px'
        };

        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.style.opacity = '1';
                    entry.target.style.transform = 'translateY(0)';
                }
            });
        }, observerOptions);

        // Назначаем анимацию карточкам
        document.querySelectorAll('.service-card, .price-card').forEach(card => {
            card.style.opacity = '0';
            card.style.transform = 'translateY(20px)';
            card.style.transition = 'opacity 0.5s, transform 0.5s';
            observer.observe(card);
        });

        // Подсветка активной ссылки в навигации при скролле
        window.addEventListener('scroll', () => {
            const sections = document.querySelectorAll('section, .header, .pricing-section, .cta-section');
            const navLinks = document.querySelectorAll('.nav-links a');
            
            let current = '';
            
            sections.forEach(section => {
                const sectionTop = section.offsetTop;
                const sectionHeight = section.clientHeight;
                if (scrollY >= (sectionTop - 100)) {
                    current = section.getAttribute('id') || '';
                }
            });
            
            navLinks.forEach(link => {
                link.classList.remove('active');
                if (link.getAttribute('href').substring(1) === current) {
                    link.classList.add('active');
                }
            });
        });

        // Управление модальным окном бронирования
        document.addEventListener('DOMContentLoaded', function() {
            const modal = document.getElementById('bookingModal');
            const openBtn = document.getElementById('openBookingModal');
            const closeBtn = document.getElementById('closeBookingModal');
            const bookingForm = document.getElementById('bookingForm');

            <?php if (isset($booking_success) && $booking_success): ?>
                // Автоматически показываем модалку с подтверждением бронирования
                modal.style.display = 'flex';
            <?php elseif (isset($booking_error)): ?>
                // Автоматически показываем модалку с ошибкой
                modal.style.display = 'flex';
            <?php endif; ?>

            if (openBtn) {
                openBtn.addEventListener('click', function() {
                    modal.style.display = 'flex';
                    document.body.style.overflow = 'hidden';
                });
            }

            if (closeBtn) {
                closeBtn.addEventListener('click', function() {
                    modal.style.display = 'none';
                    document.body.style.overflow = 'auto';
                });
            }

            // Закрытие при клике вне модального окна
            modal.addEventListener('click', function(e) {
                if (e.target === modal) {
                    modal.style.display = 'none';
                    document.body.style.overflow = 'auto';
                }
            });

            // Закрытие на Escape
            document.addEventListener('keydown', function(e) {
                if (e.key === 'Escape' && modal.style.display === 'flex') {
                    modal.style.display = 'none';
                    document.body.style.overflow = 'auto';
                }
            });

            // Синхронизация выбора услуги и стоимости
            const serviceSelect = document.querySelector('select[name="service_name"]');
            const priceSelect = document.querySelector('select[name="service_price"]');
            
            if (serviceSelect && priceSelect) {
                serviceSelect.addEventListener('change', function() {
                    const serviceName = this.value;
                    
                    // Устанавливаем соответствующую цену
                    switch(serviceName) {
                        case 'Кинозалы премиум-класса':
                            priceSelect.value = '350 ₽';
                            break;
                        case 'Пакет Еда и напитки':
                            priceSelect.value = '150 ₽';
                            break;
                        case 'VIP обслуживание':
                            priceSelect.value = '1500 ₽';
                            break;
                        case 'Детская зона':
                            priceSelect.value = '250 ₽';
                            break;
                        case '3D и IMAX сеанс':
                            priceSelect.value = '500 ₽';
                            break;
                        case 'Кинокарта на месяц':
                            priceSelect.value = '2000 ₽';
                            break;
                        case 'Семейный пакет':
                            priceSelect.value = '1000 ₽';
                            break;
                        case 'Романтический вечер':
                            priceSelect.value = '2000 ₽';
                            break;
                        case 'Корпоративный пакет':
                            priceSelect.value = '5000 ₽';
                            break;
                        default:
                            priceSelect.value = '';
                    }
                });
            }

            // Валидация формы
            if (bookingForm) {
                bookingForm.addEventListener('submit', function(e) {
                    const serviceName = document.querySelector('select[name="service_name"]').value;
                    const servicePrice = document.querySelector('select[name="service_price"]').value;
                    const bookingDate = document.querySelector('input[name="booking_date"]').value;
                    const bookingTime = document.querySelector('select[name="booking_time"]').value;
                    
                    if (!serviceName || !servicePrice || !bookingDate || !bookingTime) {
                        e.preventDefault();
                        alert('Пожалуйста, заполните все обязательные поля (отмечены *).');
                    }
                });
            }

            // Установка минимальной даты как сегодняшней
            const dateInput = document.querySelector('input[name="booking_date"]');
            if (dateInput) {
                const today = new Date().toISOString().split('T')[0];
                dateInput.min = today;
                
                // Установка значения по умолчанию на завтра
                const tomorrow = new Date();
                tomorrow.setDate(tomorrow.getDate() + 1);
                dateInput.value = tomorrow.toISOString().split('T')[0];
            }

            // Добавляем инлайн стили для выпадающих списков для лучшей совместимости
            const selects = document.querySelectorAll('.form-select');
            selects.forEach(select => {
                // Устанавливаем цвет текста и фона
                select.style.color = '#fff';
                select.style.backgroundColor = '#1a1a2e';
                
                // Для опций в выпадающем списке
                const options = select.querySelectorAll('option');
                options.forEach(option => {
                    option.style.color = '#fff';
                    option.style.backgroundColor = '#1a1a2e';
                });
            });
        });
    </script>
</body>
</html>