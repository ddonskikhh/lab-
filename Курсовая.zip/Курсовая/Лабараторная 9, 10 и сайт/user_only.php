<?php
// user_only.php - страница только для обычных пользователей
require_once 'config.php';
requireUser(); // Только обычные пользователи, не админы

$user = getCurrentUser();
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Только для пользователей</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 800px; margin: 50px auto; padding: 20px; }
        .container { background: #f9f9f9; padding: 20px; border-radius: 5px; }
        .nav { margin-bottom: 20px; }
        .nav a { margin-right: 15px; text-decoration: none; color: #007bff; }
        .info { background: #e9ecef; padding: 15px; border-radius: 5px; margin-bottom: 20px; }
    </style>
</head>
<body>
    <div class="container">
        <div class="nav">
            <a href="index.php">Главная</a>
            <a href="profile.php">Мой профиль</a>
            <a href="logout.php" style="color: #dc3545;">Выйти</a>
        </div>
        
        <h2>Страница только для обычных пользователей</h2>
        
        <div class="info">
            <p>Добро пожаловать, <strong><?php echo htmlspecialchars($user['login']); ?></strong>!</p>
            <p>Ваша роль: <strong>Обычный пользователь</strong></p>
            <p>Вы можете редактировать только свой профиль.</p>
            <p>Доступ к панели администратора для вас закрыт.</p>
        </div>
        
        <h3>Ваши возможности:</h3>
        <ul>
            <li>Просмотр и редактирование своего профиля</li>
            <li>Смена email и пароля</li>
            <li>Просмотр своей статистики</li>
        </ul>
        
        <h3>Вам недоступно:</h3>
        <ul>
            <li>Просмотр списка всех пользователей</li>
            <li>Редактирование данных других пользователей</li>
            <li>Удаление пользователей</li>
            <li>Назначение ролей</li>
        </ul>
    </div>
</body>
</html>