<?php
// register.php
require_once 'config.php';

if (isLoggedIn()) {
    header('Location: index.php');
    exit();
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $login = trim($_POST['login']);
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    
    // Валидация
    if (empty($login) || empty($email) || empty($password)) {
        $error = 'Все поля обязательны для заполнения';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Некорректный email адрес';
    } elseif ($password !== $confirm_password) {
        $error = 'Пароли не совпадают';
    } elseif (strlen($password) < 6) {
        $error = 'Пароль должен быть не менее 6 символов';
    } elseif (strlen($login) < 3) {
        $error = 'Логин должен быть не менее 3 символов';
    } else {
        try {
            $db = getDB();
            
            // Проверка существующего пользователя
            $stmt = $db->prepare("SELECT id FROM users WHERE login = ? OR email = ?");
            $stmt->execute([$login, $email]);
            
            if ($stmt->rowCount() > 0) {
                $error = 'Пользователь с таким логином или email уже существует';
            } else {
                // Создание пользователя с ролью 'user' по умолчанию
                $hashed_password = hashPassword($password);
                $stmt = $db->prepare("INSERT INTO users (login, email, password, role) VALUES (?, ?, ?, 'user')");
                $stmt->execute([$login, $email, $hashed_password]);
                
                $success = 'Регистрация успешна! Теперь вы можете войти.';
                header('refresh:2;url=login.php');
            }
        } catch(PDOException $e) {
            $error = 'Ошибка при регистрации: ' . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CINEMAX - Регистрация</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Arial', sans-serif;
        }
        
        body {
            background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
            color: #fff;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
            position: relative;
            overflow-x: hidden;
        }
        
        body::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: url('https://images.unsplash.com/photo-1489599809516-9827b6d1cf13?auto=format&fit=crop&w=1200&q=80') center/cover;
            opacity: 0.1;
            z-index: -1;
        }
        
        .container {
            width: 100%;
            max-width: 500px;
            position: relative;
            z-index: 1;
        }
        
        .logo {
            text-align: center;
            margin-bottom: 30px;
        }
        
        .logo-text {
            font-size: 48px;
            font-weight: bold;
            color: #ffd700;
            text-transform: uppercase;
            letter-spacing: 3px;
            text-shadow: 0 0 20px rgba(255, 215, 0, 0.5);
            margin-bottom: 5px;
        }
        
        .logo-subtitle {
            color: #aaa;
            font-size: 14px;
            letter-spacing: 2px;
        }
        
        .register-card {
            background: rgba(255, 255, 255, 0.05);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 215, 0, 0.2);
            border-radius: 20px;
            padding: 40px;
            box-shadow: 0 20px 50px rgba(0, 0, 0, 0.3);
            transition: transform 0.3s, box-shadow 0.3s;
        }
        
        .register-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 25px 60px rgba(255, 215, 0, 0.1);
            border-color: rgba(255, 215, 0, 0.4);
        }
        
        .card-header {
            text-align: center;
            margin-bottom: 30px;
        }
        
        .card-icon {
            width: 80px;
            height: 80px;
            background: linear-gradient(135deg, #ffd700 0%, #ffed4e 100%);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 20px;
            font-size: 32px;
            color: #000;
            box-shadow: 0 10px 20px rgba(255, 215, 0, 0.3);
        }
        
        .card-title {
            font-size: 28px;
            color: #fff;
            margin-bottom: 10px;
        }
        
        .card-subtitle {
            color: #aaa;
            font-size: 14px;
        }
        
        /* Форма */
        .form-group {
            margin-bottom: 20px;
            position: relative;
        }
        
        .form-label {
            display: block;
            margin-bottom: 8px;
            color: #ccc;
            font-size: 14px;
            font-weight: 500;
            text-transform: uppercase;
            letter-spacing: 1px;
        }
        
        .input-wrapper {
            position: relative;
        }
        
        .form-input {
            width: 100%;
            padding: 15px 20px 15px 50px;
            background: rgba(255, 255, 255, 0.08);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 10px;
            color: #fff;
            font-size: 16px;
            transition: all 0.3s;
        }
        
        .form-input:focus {
            outline: none;
            border-color: #ffd700;
            background: rgba(255, 255, 255, 0.12);
            box-shadow: 0 0 0 3px rgba(255, 215, 0, 0.1);
        }
        
        .form-input::placeholder {
            color: #777;
        }
        
        .input-icon {
            position: absolute;
            left: 20px;
            top: 50%;
            transform: translateY(-50%);
            color: #ffd700;
            font-size: 18px;
        }
        
        /* Индикаторы пароля */
        .password-strength {
            margin-top: 8px;
            display: flex;
            gap: 5px;
            height: 4px;
        }
        
        .strength-bar {
            flex: 1;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 2px;
            transition: background 0.3s;
        }
        
        .strength-bar.active {
            background: #ffd700;
        }
        
        .strength-bar.weak {
            background: #dc3545;
        }
        
        .strength-bar.medium {
            background: #ffc107;
        }
        
        .strength-bar.strong {
            background: #28a745;
        }
        
        .password-requirements {
            margin-top: 8px;
            font-size: 12px;
            color: #777;
        }
        
        .requirement {
            display: flex;
            align-items: center;
            gap: 5px;
            margin-bottom: 3px;
        }
        
        .requirement i {
            font-size: 10px;
            color: #777;
        }
        
        .requirement.valid i {
            color: #28a745;
        }
        
        /* Кнопка */
        .submit-btn {
            width: 100%;
            padding: 16px;
            background: linear-gradient(135deg, #007bff 0%, #0056b3 100%);
            border: none;
            border-radius: 10px;
            color: #fff;
            font-size: 16px;
            font-weight: bold;
            cursor: pointer;
            transition: all 0.3s;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            margin-top: 20px;
        }
        
        .submit-btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 10px 25px rgba(0, 123, 255, 0.4);
        }
        
        .submit-btn:active {
            transform: translateY(-1px);
        }
        
        /* Сообщения */
        .message {
            padding: 15px;
            border-radius: 10px;
            margin-bottom: 25px;
            display: flex;
            align-items: center;
            gap: 10px;
            animation: slideIn 0.5s ease;
        }
        
        @keyframes slideIn {
            from {
                opacity: 0;
                transform: translateY(-20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        .error-message {
            background: rgba(220, 53, 69, 0.1);
            border: 1px solid rgba(220, 53, 69, 0.3);
            color: #ff6b6b;
        }
        
        .success-message {
            background: rgba(40, 167, 69, 0.1);
            border: 1px solid rgba(40, 167, 69, 0.3);
            color: #28a745;
        }
        
        .message-icon {
            font-size: 18px;
        }
        
        /* Информационный блок */
        .info-box {
            background: rgba(255, 215, 0, 0.05);
            border: 1px solid rgba(255, 215, 0, 0.1);
            border-radius: 10px;
            padding: 15px;
            margin-top: 25px;
        }
        
        .info-title {
            color: #ffd700;
            font-size: 14px;
            font-weight: bold;
            margin-bottom: 10px;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .info-text {
            color: #aaa;
            font-size: 13px;
            line-height: 1.5;
        }
        
        /* Ссылки */
        .links-section {
            text-align: center;
            margin-top: 30px;
            padding-top: 25px;
            border-top: 1px solid rgba(255, 255, 255, 0.1);
        }
        
        .link-text {
            color: #aaa;
            margin-bottom: 15px;
            font-size: 14px;
        }
        
        .action-link {
            display: inline-block;
            padding: 12px 30px;
            background: transparent;
            border: 2px solid rgba(255, 215, 0, 0.3);
            border-radius: 50px;
            color: #ffd700;
            text-decoration: none;
            font-weight: bold;
            transition: all 0.3s;
        }
        
        .action-link:hover {
            background: rgba(255, 215, 0, 0.1);
            border-color: #ffd700;
            transform: translateY(-3px);
        }
        
        .home-link {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            margin-top: 20px;
            color: #777;
            text-decoration: none;
            font-size: 14px;
            transition: color 0.3s;
        }
        
        .home-link:hover {
            color: #ffd700;
        }
        
        /* Анимация появления */
        .register-card {
            opacity: 0;
            transform: translateY(30px);
            animation: fadeInUp 0.8s ease forwards;
        }
        
        @keyframes fadeInUp {
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        /* Адаптивность */
        @media (max-width: 480px) {
            .register-card {
                padding: 30px 20px;
            }
            
            .card-title {
                font-size: 24px;
            }
            
            .logo-text {
                font-size: 36px;
            }
            
            .card-icon {
                width: 60px;
                height: 60px;
                font-size: 24px;
            }
        }
    </style>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <div class="container">
        <div class="logo">
            <div class="logo-text">CINEMAX</div>
            <div class="logo-subtitle">РЕГИСТРАЦИЯ</div>
        </div>
        
        <div class="register-card">
            <div class="card-header">
                <div class="card-icon">
                    <i class="fas fa-user-plus"></i>
                </div>
                <h2 class="card-title">Создание аккаунта</h2>
                <p class="card-subtitle">Присоединяйтесь к нашему кинематографическому сообществу</p>
            </div>
            
            <?php if ($error): ?>
                <div class="message error-message">
                    <i class="fas fa-exclamation-circle message-icon"></i>
                    <?php echo htmlspecialchars($error); ?>
                </div>
            <?php endif; ?>
            
            <?php if ($success): ?>
                <div class="message success-message">
                    <i class="fas fa-check-circle message-icon"></i>
                    <?php echo htmlspecialchars($success); ?>
                </div>
            <?php endif; ?>
            
            <form method="POST" action="" id="registerForm">
                <div class="form-group">
                    <label class="form-label">Логин</label>
                    <div class="input-wrapper">
                        <i class="fas fa-user input-icon"></i>
                        <input type="text" 
                               name="login" 
                               class="form-input" 
                               placeholder="Придумайте логин (мин. 3 символа)" 
                               required
                               minlength="3"
                               autofocus>
                    </div>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Email адрес</label>
                    <div class="input-wrapper">
                        <i class="fas fa-envelope input-icon"></i>
                        <input type="email" 
                               name="email" 
                               class="form-input" 
                               placeholder="Введите ваш email" 
                               required>
                    </div>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Пароль</label>
                    <div class="input-wrapper">
                        <i class="fas fa-lock input-icon password-toggle"></i>
                        <input type="password" 
                               name="password" 
                               class="form-input" 
                               id="password"
                               placeholder="Создайте пароль (мин. 6 символов)" 
                               required
                               minlength="6">
                    </div>
                    <div class="password-strength" id="strengthIndicator">
                        <div class="strength-bar"></div>
                        <div class="strength-bar"></div>
                        <div class="strength-bar"></div>
                        <div class="strength-bar"></div>
                    </div>
                    <div class="password-requirements" id="passwordRequirements">
                        <div class="requirement" id="lengthReq">
                            <i class="fas fa-circle"></i>
                            <span>Минимум 6 символов</span>
                        </div>
                        <div class="requirement" id="numberReq">
                            <i class="fas fa-circle"></i>
                            <span>Содержит цифры</span>
                        </div>
                        <div class="requirement" id="letterReq">
                            <i class="fas fa-circle"></i>
                            <span>Содержит буквы</span>
                        </div>
                    </div>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Подтвердите пароль</label>
                    <div class="input-wrapper">
                        <i class="fas fa-lock input-icon confirm-toggle"></i>
                        <input type="password" 
                               name="confirm_password" 
                               class="form-input" 
                               id="confirmPassword"
                               placeholder="Повторите пароль" 
                               required
                               minlength="6">
                    </div>
                    <div class="password-match" id="passwordMatch" style="font-size: 12px; margin-top: 5px; display: none;">
                        <i class="fas fa-check" style="color: #28a745;"></i>
                        <span>Пароли совпадают</span>
                    </div>
                </div>
                
                <button type="submit" class="submit-btn" id="submitBtn">
                    <i class="fas fa-user-plus"></i>
                    Создать аккаунт
                </button>
            </form>
            
            <div class="info-box">
                <div class="info-title">
                    <i class="fas fa-info-circle"></i>
                    Информация о регистрации
                </div>
                <div class="info-text">
                    При регистрации вы получаете роль "Обычный пользователь".<br>
                    После регистрации вы сможете бронировать билеты, оставлять отзывы и получать специальные предложения.
                </div>
            </div>
            
            <div class="links-section">
                <p class="link-text">Уже есть аккаунт?</p>
                <a href="login.php" class="action-link">
                    <i class="fas fa-sign-in-alt"></i>
                    Войти в систему
                </a>
                
                <a href="index.php" class="home-link">
                    <i class="fas fa-arrow-left"></i>
                    Вернуться на главную
                </a>
            </div>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const passwordInput = document.getElementById('password');
            const confirmInput = document.getElementById('confirmPassword');
            const strengthBars = document.querySelectorAll('.strength-bar');
            const requirements = {
                length: document.getElementById('lengthReq'),
                number: document.getElementById('numberReq'),
                letter: document.getElementById('letterReq')
            };
            const passwordMatch = document.getElementById('passwordMatch');
            const submitBtn = document.getElementById('submitBtn');
            
            // Показать/скрыть пароль
            const toggleIcons = document.querySelectorAll('.input-icon');
            toggleIcons.forEach(icon => {
                if (icon.classList.contains('fa-lock')) {
                    icon.addEventListener('click', function() {
                        const input = this.closest('.input-wrapper').querySelector('input');
                        if (input.type === 'password') {
                            input.type = 'text';
                            this.classList.remove('fa-lock');
                            this.classList.add('fa-unlock');
                        } else {
                            input.type = 'password';
                            this.classList.remove('fa-unlock');
                            this.classList.add('fa-lock');
                        }
                    });
                }
            });
            
            // Проверка сложности пароля
            function checkPasswordStrength(password) {
                let strength = 0;
                
                // Длина
                if (password.length >= 6) {
                    strength++;
                    requirements.length.classList.add('valid');
                } else {
                    requirements.length.classList.remove('valid');
                }
                
                // Наличие цифр
                if (/\d/.test(password)) {
                    strength++;
                    requirements.number.classList.add('valid');
                } else {
                    requirements.number.classList.remove('valid');
                }
                
                // Наличие букв
                if (/[a-zA-Z]/.test(password)) {
                    strength++;
                    requirements.letter.classList.add('valid');
                } else {
                    requirements.letter.classList.remove('valid');
                }
                
                // Обновление индикатора
                strengthBars.forEach((bar, index) => {
                    bar.classList.remove('active', 'weak', 'medium', 'strong');
                    if (index < strength) {
                        bar.classList.add('active');
                        if (strength === 1) {
                            bar.classList.add('weak');
                        } else if (strength === 2) {
                            bar.classList.add('medium');
                        } else if (strength === 3) {
                            bar.classList.add('strong');
                        }
                    }
                });
                
                return strength;
            }
            
            // Проверка совпадения паролей
            function checkPasswordMatch() {
                if (passwordInput.value && confirmInput.value) {
                    if (passwordInput.value === confirmInput.value) {
                        passwordMatch.style.display = 'flex';
                        return true;
                    } else {
                        passwordMatch.style.display = 'none';
                        return false;
                    }
                }
                return false;
            }
            
            // События ввода
            passwordInput.addEventListener('input', function() {
                checkPasswordStrength(this.value);
                checkPasswordMatch();
            });
            
            confirmInput.addEventListener('input', checkPasswordMatch);
            
            // Валидация формы перед отправкой
            document.getElementById('registerForm').addEventListener('submit', function(e) {
                const password = passwordInput.value;
                const confirm = confirmInput.value;
                
                if (password.length < 6) {
                    e.preventDefault();
                    alert('Пароль должен быть не менее 6 символов');
                    return;
                }
                
                if (password !== confirm) {
                    e.preventDefault();
                    alert('Пароли не совпадают');
                    return;
                }
                
                // Проверка сложности (опционально)
                const strength = checkPasswordStrength(password);
                if (strength < 2) {
                    if (!confirm('Ваш пароль слабый. Вы уверены, что хотите продолжить?')) {
                        e.preventDefault();
                        return;
                    }
                }
                
                submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Регистрация...';
                submitBtn.disabled = true;
            });
            
            // Анимация фокуса
            const inputs = document.querySelectorAll('.form-input');
            inputs.forEach(input => {
                input.addEventListener('focus', function() {
                    this.parentElement.style.transform = 'scale(1.02)';
                });
                
                input.addEventListener('blur', function() {
                    this.parentElement.style.transform = 'scale(1)';
                });
            });
        });
    </script>
</body>
</html>