// Обработка выбора способа доставки
document.querySelectorAll('.delivery-option').forEach(option => {
    option.addEventListener('click', function() {
        // Убираем выделение со всех вариантов
        document.querySelectorAll('.delivery-option').forEach(opt => {
            opt.classList.remove('selected');
        });
        
        // Выделяем выбранный вариант
        this.classList.add('selected');
        
        // Обновляем скрытое поле
        document.getElementById('deliveryMethod').value = this.dataset.value;
    });
});

// Обработка выбора способа оплаты
document.querySelectorAll('.payment-method').forEach(method => {
    method.addEventListener('click', function() {
        // Убираем выделение со всех вариантов
        document.querySelectorAll('.payment-method').forEach(meth => {
            meth.classList.remove('selected');
        });
        
        // Выделяем выбранный вариант
        this.classList.add('selected');
        
        // Обновляем скрытое поле
        document.getElementById('paymentMethod').value = this.dataset.value;
    });
});

// Функция валидации телефона
function validatePhone(phone) {
    // Разрешаем цифры, пробелы, скобки, плюс и тире
    const phoneRegex = /^[\d\s()+-]+$/;
    const digitsOnly = phone.replace(/\D/g, '');
    return phoneRegex.test(phone) && digitsOnly.length >= 10;
}

// Функция валидации email
function validateEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}

// Функция валидации индекса
function validateZip(zip) {
    const zipRegex = /^\d{6}$/;
    return zipRegex.test(zip);
}

// Функция показа ошибки
function showError(elementId, message) {
    const errorElement = document.getElementById(`${elementId}Error`);
    const inputElement = document.getElementById(elementId);
    
    if (errorElement && inputElement) {
        errorElement.textContent = message;
        errorElement.style.display = 'block';
        inputElement.classList.add('error');
    }
}

// Функция скрытия ошибки
function hideError(elementId) {
    const errorElement = document.getElementById(`${elementId}Error`);
    const inputElement = document.getElementById(elementId);
    
    if (errorElement && inputElement) {
        errorElement.style.display = 'none';
        inputElement.classList.remove('error');
    }
}

// Функция проверки чекбокса соглашения
function validateCheckbox() {
    const checkbox = document.getElementById('agreement');
    const checkboxError = document.getElementById('agreementError');
    const checkboxGroup = document.querySelector('.checkbox-group');
    
    if (!checkbox.checked) {
        checkboxError.style.display = 'block';
        checkboxGroup.classList.add('error');
        return false;
    } else {
        checkboxError.style.display = 'none';
        checkboxGroup.classList.remove('error');
        return true;
    }
}

// Функция валидации всей формы
function validateForm(formData) {
    let isValid = true;
    
    // Проверка обязательных полей
    const requiredFields = ['firstName', 'lastName', 'email', 'phone', 'address', 'city', 'zip'];
    
    requiredFields.forEach(field => {
        const value = formData.get(field);
        if (!value || value.trim() === '') {
            showError(field, 'Это поле обязательно для заполнения');
            isValid = false;
        } else {
            hideError(field);
        }
    });
    
    // Проверка email
    const email = formData.get('email');
    if (email && email.trim() !== '') {
        if (!validateEmail(email)) {
            showError('email', 'Введите корректный email адрес');
            isValid = false;
        }
    }
    
    // Проверка телефона
    const phone = formData.get('phone');
    if (phone && phone.trim() !== '') {
        if (!validatePhone(phone)) {
            showError('phone', 'Введите корректный номер телефона (минимум 10 цифр)');
            isValid = false;
        }
    }
    
    // Проверка индекса
    const zip = formData.get('zip');
    if (zip && zip.trim() !== '') {
        if (!validateZip(zip)) {
            showError('zip', 'Индекс должен состоять из 6 цифр');
            isValid = false;
        }
    }
    
    // Проверка страны
    const country = formData.get('country');
    if (!country) {
        showError('country', 'Выберите страну');
        isValid = false;
    } else {
        hideError('country');
    }
    
    // Проверка соглашения
    if (!validateCheckbox()) {
        isValid = false;
    }
    
    return isValid;
}

// Функция очистки формы
function clearForm() {
    const form = document.getElementById('orderForm');
    form.reset();
    
    // Сброс выбранных вариантов доставки и оплаты
    document.querySelectorAll('.delivery-option').forEach(opt => {
        opt.classList.remove('selected');
    });
    document.querySelector('.delivery-option[data-value="courier"]').classList.add('selected');
    document.getElementById('deliveryMethod').value = 'courier';
    
    document.querySelectorAll('.payment-method').forEach(meth => {
        meth.classList.remove('selected');
    });
    document.querySelector('.payment-method[data-value="card"]').classList.add('selected');
    document.getElementById('paymentMethod').value = 'card';
    
    // Скрытие всех ошибок
    document.querySelectorAll('.error-message').forEach(error => {
        error.style.display = 'none';
    });
    
    document.querySelectorAll('.checkbox-error').forEach(error => {
        error.style.display = 'none';
    });
    
    document.querySelectorAll('input, select, textarea').forEach(element => {
        element.classList.remove('error');
    });
    
    document.querySelector('.checkbox-group').classList.remove('error');
}

// Функция отображения данных заказа
function displayOrderData(formData) {
    const summaryContainer = document.querySelector('.order-summary');
    const originalCart = document.querySelector('.cart-items');
    const originalTotal = document.querySelector('.order-total');
    
    // Скрываем оригинальную корзину
    if (originalCart) originalCart.style.display = 'none';
    if (originalTotal) originalTotal.style.display = 'none';
    
    // Создаем контейнер для отображения данных
    let dataHTML = `
        <div class="order-data">
            <h3>Ваши данные заказа</h3>
            <div class="data-section">
                <h4>Личная информация:</h4>
                <p><strong>Имя:</strong> ${formData.get('firstName')} ${formData.get('lastName')}</p>
                <p><strong>Email:</strong> ${formData.get('email')}</p>
                <p><strong>Телефон:</strong> ${formData.get('phone')}</p>
            </div>
            
            <div class="data-section">
                <h4>Адрес доставки:</h4>
                <p><strong>Адрес:</strong> ${formData.get('address')}</p>
                <p><strong>Город:</strong> ${formData.get('city')}</p>
                <p><strong>Индекс:</strong> ${formData.get('zip')}</p>
                <p><strong>Страна:</strong> ${formData.get('country') === 'RU' ? 'Россия' : 
                                           formData.get('country') === 'BY' ? 'Беларусь' :
                                           formData.get('country') === 'KZ' ? 'Казахстан' : 'Украина'}</p>
            </div>
            
            <div class="data-section">
                <h4>Способ доставки:</h4>
                <p>${formData.get('deliveryMethod') === 'courier' ? 'Курьером (1-2 дня, 300 руб.)' :
                     formData.get('deliveryMethod') === 'pickup' ? 'Самовывоз (бесплатно)' :
                     'Почта России (5-10 дней, 200 руб.)'}</p>
            </div>
            
            <div class="data-section">
                <h4>Способ оплаты:</h4>
                <p>${formData.get('paymentMethod') === 'card' ? 'Банковская карта' :
                     formData.get('paymentMethod') === 'cash' ? 'Наличные при получении' :
                     'Онлайн-оплата'}</p>
            </div>
    `;
    
    if (formData.get('comments')) {
        dataHTML += `
            <div class="data-section">
                <h4>Комментарий:</h4>
                <p>${formData.get('comments')}</p>
            </div>
        `;
    }
    
    dataHTML += `
            <div class="order-total" style="display: block;">
                <div class="total-label">Итого:</div>
                <div class="total-price">11 330 руб.</div>
            </div>
            
            <div class="success-message">
                <p>✅ Заказ успешно оформлен! Спасибо за покупку.</p>
                <p>Наш менеджер свяжется с вами в течение 30 минут для подтверждения заказа.</p>
            </div>
            
            <button type="button" class="change-btn" id="changeOrderBtn">Изменить заказ</button>
        </div>
    `;
    
    // Добавляем данные в блок заказа
    if (!document.querySelector('.order-data')) {
        summaryContainer.insertAdjacentHTML('beforeend', dataHTML);
        
        // Показываем кнопку изменения
        document.getElementById('changeOrderBtn').classList.add('show');
        
        // Добавляем обработчик для кнопки "Изменить"
        document.getElementById('changeOrderBtn').addEventListener('click', function() {
            // Удаляем отображенные данные
            document.querySelector('.order-data').remove();
            
            // Показываем оригинальную корзину
            if (originalCart) originalCart.style.display = 'block';
            if (originalTotal) originalTotal.style.display = 'flex';
            
            // Скрываем кнопку изменения
            this.style.display = 'none';
        });
    }
}

// Обработчик отправки формы
document.getElementById('orderForm').addEventListener('submit', function(event) {
    event.preventDefault();
    
    // Скрываем предыдущие уведомления
    const successMessage = document.querySelector('.success-message');
    if (successMessage) successMessage.classList.remove('show');
    
    // Получаем данные формы
    const formData = new FormData(this);
    
    // Валидация формы
    if (validateForm(formData)) {
        // Показываем уведомление об успехе
        const successDiv = document.createElement('div');
        successDiv.className = 'success-message show';
        successDiv.innerHTML = '<p>✅ Форма успешно проверена! Отправляем данные...</p>';
        
        // Вставляем уведомление перед формой
        const orderForm = document.querySelector('.order-form');
        orderForm.insertBefore(successDiv, orderForm.firstChild);
        
        // Имитация отправки данных
        setTimeout(() => {
            // Отображаем данные заказа
            displayOrderData(formData);
            
            // Очищаем форму
            clearForm();
            
            // Обновляем уведомление
            successDiv.innerHTML = '<p>✅ Заказ успешно отправлен! Данные сохранены.</p>';
            
            // Прокручиваем к верху
            window.scrollTo({ top: 0, behavior: 'smooth' });
        }, 1000);
    }
});

// Реальная валидация при вводе (для лучшего UX)
document.querySelectorAll('input, select, textarea').forEach(element => {
    element.addEventListener('input', function() {
        const fieldId = this.id;
        if (fieldId) {
            hideError(fieldId);
        }
    });
    
    element.addEventListener('change', function() {
        const fieldId = this.id;
        if (fieldId) {
            hideError(fieldId);
        }
    });
});

// Проверка соглашения при изменении
document.getElementById('agreement').addEventListener('change', function() {
    validateCheckbox();
});