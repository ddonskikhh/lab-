<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Задания - Таблица умножения, Календарь, Регистрация</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <header>
            <h1>Три задания на PHP/JavaScript</h1>
            <p class="subtitle">Таблица умножения • Календарь • Форма регистрации</p>
        </header>

        <div class="tasks-grid">
            <!-- Задание 1: Таблица умножения (генерируется PHP) -->
            <div class="task-card">
                <h2>Задание 1: Таблица умножения (0-10)</h2>
                <p>Таблица умножения чисел от 0 до 10:</p>
                <div class="multiplication-table-container">
                    <div class="multiplication-table" id="multiplicationTable">
                        <?php
                        // Генерация таблицы умножения на PHP
                        echo '<div>×</div>'; // Угловая ячейка
                        
                        // Заголовки столбцов
                        for ($i = 0; $i <= 10; $i++) {
                            echo '<div class="header-col">' . $i . '</div>';
                        }
                        
                        // Основная часть таблицы
                        for ($i = 0; $i <= 10; $i++) {
                            // Заголовок строки
                            echo '<div class="header-row">' . $i . '</div>';
                            
                            // Ячейки с результатами
                            for ($j = 0; $j <= 10; $j++) {
                                $result = $i * $j;
                                echo '<div class="cell" title="' . $i . ' × ' . $j . ' = ' . $result . '">' . $result . '</div>';
                            }
                        }
                        ?>
                    </div>
                </div>
            </div>

            <!-- Задание 2: Календарь -->
            <div class="task-card">
                <h2>Задание 2: Календарь на месяц</h2>
                <div class="calendar-controls">
                    <form method="GET" action="" id="calendarForm">
                        <input type="number" name="year" id="year" min="1900" max="2100" 
                               placeholder="Год" value="<?php echo isset($_GET['year']) ? htmlspecialchars($_GET['year']) : date('Y'); ?>">
                        <select name="month" id="month">
                            <?php
                            $months = [
                                1 => 'Январь', 2 => 'Февраль', 3 => 'Март', 
                                4 => 'Апрель', 5 => 'Май', 6 => 'Июнь',
                                7 => 'Июль', 8 => 'Август', 9 => 'Сентябрь',
                                10 => 'Октябрь', 11 => 'Ноябрь', 12 => 'Декабрь'
                            ];
                            $currentMonth = isset($_GET['month']) ? (int)$_GET['month'] : date('n');
                            foreach ($months as $num => $name) {
                                $selected = ($num == $currentMonth) ? 'selected' : '';
                                echo "<option value=\"$num\" $selected>$name</option>";
                            }
                            ?>
                        </select>
                        <button type="submit">Показать календарь</button>
                    </form>
                </div>
                <div class="calendar-container">
                    <div class="calendar" id="calendar">
                        <?php
                        // Функция для генерации календаря на PHP
                        function generateCalendarPHP($year = null, $month = null) {
                            $months = [
                                1 => 'Январь', 2 => 'Февраль', 3 => 'Март', 
                                4 => 'Апрель', 5 => 'Май', 6 => 'Июнь',
                                7 => 'Июль', 8 => 'Август', 9 => 'Сентябрь',
                                10 => 'Октябрь', 11 => 'Ноябрь', 12 => 'Декабрь'
                            ];
                            
                            $year = $year ?? date('Y');
                            $month = $month ?? date('n');
                            
                            // Дни недели
                            $daysOfWeek = ['Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб', 'Вс'];
                            
                            // Выводим заголовки дней
                            foreach ($daysOfWeek as $day) {
                                echo '<div class="calendar-day header" title="' . $day . '">' . $day . '</div>';
                            }
                            
                            // Первый день месяца
                            $firstDay = mktime(0, 0, 0, $month, 1, $year);
                            $daysInMonth = date('t', $firstDay);
                            $startDay = date('N', $firstDay) - 1; // Пн=0, Вт=1, ..., Вс=6
                            
                            // Пустые ячейки перед первым днем
                            $prevMonthDays = date('t', mktime(0, 0, 0, $month - 1, 1, $year));
                            for ($i = 0; $i < $startDay; $i++) {
                                $day = $prevMonthDays - $startDay + $i + 1;
                                echo '<div class="calendar-day other-month">' . $day . '</div>';
                            }
                            
                            // Дни месяца
                            $today = date('j');
                            $currentMonthNum = date('n');
                            $currentYear = date('Y');
                            
                            // Праздничные дни
                            $holidays = [
                                '01-01', '01-02', '01-03', '01-04', '01-05', '01-06', '01-07',
                                '02-23', '03-08', '05-01', '05-09', '06-12', '11-04', '12-31'
                            ];
                            
                            for ($day = 1; $day <= $daysInMonth; $day++) {
                                $date = sprintf('%02d-%02d', $month, $day);
                                $isToday = ($day == $today && $month == $currentMonthNum && $year == $currentYear);
                                $dayOfWeek = date('N', mktime(0, 0, 0, $month, $day, $year));
                                $isWeekend = ($dayOfWeek >= 6);
                                $isHoliday = in_array($date, $holidays);
                                
                                $classes = 'calendar-day';
                                if ($isToday) $classes .= ' today';
                                if ($isWeekend) $classes .= ' weekend';
                                if ($isHoliday) $classes .= ' holiday';
                                
                                $monthName = $months[$month] ?? 'Неизвестный месяц';
                                echo '<div class="' . $classes . '" title="' . $day . ' ' . 
                                     $monthName . ' ' . $year . '">' . $day . '</div>';
                            }
                            
                            // Завершаем сетку следующими днями
                            $totalCells = 42; // 6 строк по 7 дней
                            $currentCells = $startDay + $daysInMonth;
                            if ($currentCells < $totalCells) {
                                for ($i = 1; $i <= ($totalCells - $currentCells); $i++) {
                                    echo '<div class="calendar-day other-month">' . $i . '</div>';
                                }
                            }
                        }
                        
                        // Генерируем календарь
                        $year = isset($_GET['year']) ? (int)$_GET['year'] : date('Y');
                        $month = isset($_GET['month']) ? (int)$_GET['month'] : date('n');
                        generateCalendarPHP($year, $month);
                        ?>
                    </div>
                </div>
            </div>

            <!-- Задание 3: Форма регистрации -->
            <div class="task-card">
                <h2>Задание 3: Регистрация пользователя</h2>
                
                <?php
                // Обработка формы регистрации
                if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['register'])) {
                    $errors = [];
                    $success = false;
                    
                    // Валидация данных
                    $fullName = trim($_POST['fullName'] ?? '');
                    $login = trim($_POST['login'] ?? '');
                    $password = $_POST['password'] ?? '';
                    $birthDate = $_POST['birthDate'] ?? '';
                    
                    // Проверка ФИО
                    if (empty($fullName)) {
                        $errors['fullName'] = 'ФИО обязательно для заполнения';
                    } elseif (strlen($fullName) < 5 || substr_count($fullName, ' ') < 1) {
                        $errors['fullName'] = 'Введите полное ФИО (минимум 2 слова)';
                    }
                    
                    // Проверка логина
                    if (empty($login)) {
                        $errors['login'] = 'Логин обязателен для заполнения';
                    } elseif (strlen($login) < 3) {
                        $errors['login'] = 'Логин должен содержать не менее 3 символов';
                    } elseif (!preg_match('/^[a-zA-Z0-9_]+$/', $login)) {
                        $errors['login'] = 'Логин может содержать только буквы, цифры и подчеркивания';
                    }
                    
                    // Проверка пароля
                    if (empty($password)) {
                        $errors['password'] = 'Пароль обязателен для заполнения';
                    } elseif (strlen($password) < 6) {
                        $errors['password'] = 'Пароль должен содержать не менее 6 символов';
                    } elseif (!preg_match('/[A-Z]/', $password) || 
                              !preg_match('/[a-z]/', $password) || 
                              !preg_match('/[0-9]/', $password)) {
                        $errors['password'] = 'Пароль должен содержать заглавные, строчные буквы и цифры';
                    }
                    
                    // Проверка даты рождения
                    if (empty($birthDate)) {
                        $errors['birthDate'] = 'Дата рождения обязательна для заполнения';
                    } else {
                        $birthDateObj = DateTime::createFromFormat('Y-m-d', $birthDate);
                        $today = new DateTime();
                        $minDate = clone $today;
                        $minDate->modify('-100 years');
                        $maxDate = clone $today;
                        $maxDate->modify('-14 years');
                        
                        if ($birthDateObj > $maxDate) {
                            $errors['birthDate'] = 'Вам должно быть не менее 14 лет';
                        } elseif ($birthDateObj < $minDate) {
                            $errors['birthDate'] = 'Введите корректную дату рождения';
                        }
                    }
                    
                    // Если ошибок нет, сохраняем данные в users.txt
                    if (empty($errors)) {
                        $success = true;
                        
                        // Сохраняем данные в текстовый файл
                        $dataLine = date('Y-m-d H:i:s') . ' | ' . 
                                   $login . ' | ' . 
                                   $fullName . ' | ' . 
                                   $birthDate;
                        
                        file_put_contents('users.txt', $dataLine . PHP_EOL, FILE_APPEND);
                        
                        // Выводим сообщение об успехе
                        echo '<div class="message success">✅ Регистрация успешно завершена! Данные сохранены.</div>';
                    }
                }
                ?>
                
                <form id="registrationForm" class="registration-form" method="POST" action="">
                    <div class="form-group">
                        <label for="fullName">ФИО:</label>
                        <input type="text" id="fullName" name="fullName" 
                               placeholder="Иванов Иван Иванович" 
                               value="<?php echo htmlspecialchars($_POST['fullName'] ?? ''); ?>" 
                               required>
                        <?php if (isset($errors['fullName'])): ?>
                            <div class="validation-message show"><?php echo $errors['fullName']; ?></div>
                        <?php else: ?>
                            <div class="validation-message" id="fullNameError"></div>
                        <?php endif; ?>
                    </div>

                    <div class="form-group">
                        <label for="login">Логин:</label>
                        <input type="text" id="login" name="login" 
                               placeholder="Придумайте логин" 
                               value="<?php echo htmlspecialchars($_POST['login'] ?? ''); ?>" 
                               required>
                        <?php if (isset($errors['login'])): ?>
                            <div class="validation-message show"><?php echo $errors['login']; ?></div>
                        <?php else: ?>
                            <div class="validation-message" id="loginError"></div>
                        <?php endif; ?>
                    </div>

                    <div class="form-group">
                        <label for="password">Пароль:</label>
                        <input type="password" id="password" name="password" 
                               placeholder="Не менее 6 символов" required>
                        <?php if (isset($errors['password'])): ?>
                            <div class="validation-message show"><?php echo $errors['password']; ?></div>
                        <?php else: ?>
                            <div class="validation-message" id="passwordError"></div>
                        <?php endif; ?>
                    </div>

                    <div class="form-group">
                        <label for="birthDate">Дата рождения:</label>
                        <input type="date" id="birthDate" name="birthDate" 
                               value="<?php echo htmlspecialchars($_POST['birthDate'] ?? ''); ?>" 
                               required>
                        <?php if (isset($errors['birthDate'])): ?>
                            <div class="validation-message show"><?php echo $errors['birthDate']; ?></div>
                        <?php else: ?>
                            <div class="validation-message" id="birthDateError"></div>
                        <?php endif; ?>
                    </div>

                    <button type="submit" name="register" class="submit-btn">Зарегистрироваться</button>
                </form>
            </div>
        </div>

        <footer>
            <p>Все задания выполнены с использованием HTML, CSS, PHP и JavaScript</p>
            <p>Текущая дата на сервере: <?php echo date('d.m.Y H:i:s'); ?></p>
        </footer>
    </div>
</body>
</html>